#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <time.h>

#define SERVERPORT 4950
#define MAXBUFLEN 100

char* myProcessID;
char* listenID1;
char* listenID2;
void *anomaly( void *host );
void *tricorder( void *ptr );

/*
 * Main Function
 * The program requires 5 aurguments to run.
 * ProcessID = The Process ID of THIS process. It is the ID it will send to the listeners to identify itself
 * SendToHostName1 = The Hostname of the machine it is to send one of its heartbeats to
 * SendToHostName2 = Another Hostname to send one of its heartbeats to
 * ListenProcessID1 = A Process ID to listen for. The Listener will only count messages if the sent ID is one of the ListenIDs that are put here
 * ListenProcessID2 = Another ProcessID to listen for.
 * 
 * The Main function spawns 3 threads. 
 * 1 Listener thread to listen to all incoming messages
 * 2 Talker threads. Each talker thread talks to a host via UDP
 * 
 */

main(int argc, char* argv[])
{
 /* initialize random seed: */
  srand ( time(NULL) );
  
    pthread_t listener, talker1, talker2;

    if (argc != 6) {
		printf("Usage: %s <ProcessID> <SendToHostName1> <SendToHostName2> <ListenProcessID1> <ListenProcessID2>\n", argv[0]);
		exit(1);
    }

    myProcessID = argv[1];
    listenID1 = argv[4];
    listenID2 = argv[5];

    pthread_create( &listener, NULL, tricorder, NULL);
    pthread_create( &talker1, NULL, anomaly, (void*) argv[2]);
    pthread_create( &talker2, NULL, anomaly, (void*) argv[3]);

    pthread_join( listener, NULL);
    pthread_join( talker1, NULL);
    pthread_join( talker2, NULL);

    exit(0);
}

// This function is the Talker function. It is technically the 'Client' side of the code
// It uses one of the hostnames given to it by the parameters.
// And then connects to that host. It then runs an infinite loop, sending a heartbeat message every 5 seconds.
// The Message is of this format: MyProcessID_MessageID, Where MyProcessID is constant, and given via the parameters. 
// And MessageID is an ID from 0-9, and loops back on itself.
//
// This function also adds a 50% message loss to the message sending.
// A random number was chosen, and then based on that number, the message was either dropped or sent normally.
// This is to simulate a 'False-Positive' Rate in the listener.
void *anomaly (void *host )
{
    char *hostname;
    hostname = (char *) host;
    int sockfd;
    struct sockaddr_in their_addr; // connector's address information
    struct hostent *he;
    int numbytes;

    if ((he=gethostbyname(hostname)) == NULL) {  // get the host info
		perror("gethostbyname");
		exit(1);
    }
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("socket");
		exit(1);
    }
    their_addr.sin_family = AF_INET;     // host byte order
    their_addr.sin_port = htons(SERVERPORT); // short, network byte order
    their_addr.sin_addr = *((struct in_addr *)he->h_addr);
    memset(&(their_addr.sin_zero), '\0', 8);  // zero the rest of the struct
    int count = 0;
    for (;;) {
		count++;
		if (count >= 10) {
			count = 1;
		}
		char buf[strlen(myProcessID)+3];
		sprintf(buf, "%s_%d", myProcessID, count);
		int sent;

		/* generate secret number: */
		sent = rand() % 100;
		if(sent < 50)
		{
			if ((numbytes = sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr *)&their_addr, sizeof(struct sockaddr))) == -1) {
				perror("sendto");
				exit(1);
			}
			printf("Sent %d bytes to %s at %d\n", numbytes, hostname, time(NULL));
		} else {
			printf("Message not sent to %s at %d\n", hostname, time(NULL));
		}
		sleep(5);
    }
    close(sockfd);
}

// The tricorder function is the 'Listener' of the FD. It is technically the 'Server' side of the code
// This function (threaded) keeps track of each host. It gives each host 5 minutes to initially connect.
// Once it has connected, it gives each host 10 seconds to send a heatbeat, otherwise it declares that host as having failed. 
void *tricorder( void *ptr )
{
    int sockfd;
    struct sockaddr_in my_addr;    // my address information
    struct sockaddr_in their_addr; // connector's address information
    socklen_t addr_len;
    int numbytes;
    char buf[MAXBUFLEN];
    struct listenhost {
		int lastid; // The message ID must be higher than the last ID for the heartbeat to count
		long time_to_crash; // The timestamp at which the sender will be considered Dead
		char* hostname; // The hostname (or process ID) of the sending process
		int crashed; // A flag to determine if this process ID has already crashed
    };
	// Initializing each listenhost struct.
    int numhosts = 2;
    struct listenhost hosts[numhosts];
    hosts[0].lastid = 0;
    hosts[0].time_to_crash = time(NULL) + (60*5); // Client has 5 minutes to connect
    hosts[0].hostname = listenID1;
    hosts[0].crashed = 0;
    hosts[1].lastid = 0;
    hosts[1].time_to_crash = time(NULL) + (60*5); // Client has 5 minutes to connect
    hosts[1].hostname = listenID2;
    hosts[1].crashed = 0;

    // Setting up the socket
    if ((sockfd = socket(PF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("socket");
		exit(1);
    }

    // Making the socket NON-Blocking so that the program doesn't wait for a message, and can use those cycles to check to see if a host has died.
    int flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

    // Setsup the address and binds it to the socket.
    my_addr.sin_family = AF_INET;         // host byte order
    my_addr.sin_port = htons(SERVERPORT);     // short, network byte order
    my_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
    memset(&(my_addr.sin_zero), '\0', 8); // zero the rest of the struct
    if (bind(sockfd, (struct sockaddr *)&my_addr,
		sizeof(struct sockaddr)) == -1) {
		perror("bind");
		exit(1);
    }

    addr_len = sizeof(struct sockaddr);
    int i;
    // Intential Infinte Loop
    for (;;) {
		if ((numbytes=recvfrom(sockfd, buf, MAXBUFLEN-1 , 0, (struct sockaddr *)&their_addr, &addr_len)) == -1) {
			// If we did not recieve a message, check all of the hosts to make sure their 'time_to_crash' has not passed.
			// If it has passed, that host has crashed.
			for (i = 0; i < (numhosts); i++) {
				if (hosts[i].crashed == 0 && time(NULL) >= hosts[i].time_to_crash) {
					hosts[i].crashed = 1;
					printf("\nHost: %s has Crashed!!!\nCrash was Deteced at %d\n\n", hosts[i].hostname, time(NULL));
				}
			}
		} else {
			// If we did recieve a message, match it to the correct host, check its message ID, and then reset that hosts time_to_crash
			buf[numbytes] = '\0';
			int id = (int) (buf[numbytes-1] - '0');
			char hostname[numbytes-1];
			strncpy(hostname, buf, (numbytes-2));
			hostname[numbytes-2] = '\0';
			printf("Recieved %d bytes from Process ID %s at %d\n", numbytes, hostname, time(NULL));
			for (i = 0; i < (numhosts); i++) {
				if (strcmp(hostname, hosts[i].hostname) == 0 && id > hosts[i].lastid) {
					if (id == 9) id = 0;
					hosts[i].lastid = id;
					hosts[i].time_to_crash = time(NULL) + 10;
				}
			}
		}
    }
    close(sockfd);
}
