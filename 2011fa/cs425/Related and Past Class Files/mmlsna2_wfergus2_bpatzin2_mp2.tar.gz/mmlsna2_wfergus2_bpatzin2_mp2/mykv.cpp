/*
* mykv.cpp
* By: Brian Patzin, Mike Mlsna, Will Ferguson
*
*          DESCRIPTION:     
*            Create a distributed key-value store across 4 nodes    
*           which supports insert, lookup, and delete operations   
*            The distributed system is load balanced in both storage
*            and network traffic.                                   
*                                                                   
*         ARGUMENTS:                                                
*           config-file         - Hostnames and ports of other nodes
*                                 in the system                     
*
* 	Commands:
* 	  query <key>
*	  insert <key> <value>
*	  delete <key>
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cmath>
#include <ctime>
#include <iostream>
#include <algorithm>
#include <iterator>
#include <vector>
#include <map>
#include <string>
#include <sstream>
#include <fstream>

#include "mykv.hpp"
#include "Node.hpp"
#include "Util.hpp"
#include "BSTNode.hpp"

//Port the nodes communicate on
#define PORT "9900"

//Port the IO threads listen to
#define IOPORT "9901"

using namespace std;


#if 1
static const int MAX_ADDR = 256;
static const int MAXBUFLEN = 100;
static const int SEND_INTERVAL = 7;
static const int RECV_TIMEOUT = 8;
#endif

static vector<Node> g_nodes;

static int g_id;

//vector<Node> peers;
vector<string> local_hostnames;

static const int NUM_BST_NODES = 63;

// Create the node_id_table
static int g_tree_node_id_table[NUM_BST_NODES] = {
    0,
    1, 1,
    2, 2, 2, 2,
    3, 3, 3, 3, 3, 3, 3, 3,
    0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3
};

//List of messages that nodes send to one another
enum MessageType
{
    QUERY,
    INSERT,
    DELETE,
    RETURN_VALUE,
    DONE
};


// All of the BSTNode vertices at this node
static map< int, BSTNode<int> > g_bst_nodes;

//Initialize the nodes located on local process
static void initialize_bst_nodes(int id)
{
    for(int i = 0; i < NUM_BST_NODES; i++)
    {
        if(g_tree_node_id_table[i] == id)
        {
            BSTNode<int> tree_node(i);
            g_bst_nodes[i] = tree_node;
        }
    }
}

// Print the usage information
void usage(void)
{
    string usage =
        "usage: mykv config                                         \n"
        "                                                           \n"
        "  DESCRIPTION:                                             \n"
        "    Create a distributed key-value store across 4 nodes    \n"
        "    which supports insert, lookup, and delete operations   \n"
        "    The distributed system is load balanced in both storage\n"
        "    and network traffic.                                   \n"
        "                                                           \n"
        " ARGUMENTS:                                                \n"
        "   config-file         - Hostnames and ports of other nodes\n"
        "                         in the system                     \n";
    cout << usage << endl;
}

// Insert all nodes in the node-file into the vector
vector<Node> parse_config(const char *filename)
{
    ifstream file(filename);
    if(!file.is_open())
    {
        ERROR_EXIT("Unable to open peer file");
    }

    string line;

    vector<Node> nodes;
    int count = 0;
    // Read the network addresses
    while(!file.eof())
    {
        getline(file, line);
        if(line == "")
        {
            break;
        }

        istringstream iss(line);
        vector<string> tokens;
        copy(istream_iterator<string>(iss),
            istream_iterator<string>(),
            back_inserter<vector<string> >(tokens));

        // Split line into hostname and ports
        Node node(count++, tokens[0], tokens[1], tokens[2]);


//DOES THIS BLOCK GET USED?
/**************************************************************************************************************/
    struct addrinfo hints;
    struct addrinfo* servinfo;
    struct addrinfo* p;
    int rv;

        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
        hints.ai_socktype = SOCK_DGRAM;
        hints.ai_flags = AI_PASSIVE; // use my IP

        if ((rv = getaddrinfo(tokens[0].c_str(), tokens[1].c_str(), &hints, &servinfo)) != 0) {
            ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
        }

        // loop through all the results and bind to the first we can
        for(p = servinfo; p != NULL; p = p->ai_next) {
            node.addrinfo = *p;
        }

        freeaddrinfo(servinfo);

        if ((rv = getaddrinfo(tokens[0].c_str(), tokens[2].c_str(), &hints, &servinfo)) != 0) {
            ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
        }

        // loop through all the results and bind to the first we can
        for(p = servinfo; p != NULL; p = p->ai_next) {
            node.io_addrinfo = *p;
        }

        freeaddrinfo(servinfo);
/*****************************************************************************************************************/

        nodes.push_back(node);

    }

    file.close();

    return nodes;
}


// Return list of hostnames available on the localhost
vector<string> gethostnames(void)
{
    char hostname[MAX_ADDR];
    struct addrinfo hints, *info, *p;
    int rv;

    vector<string> hostnames;

    // Clear out the hostname vector
    hostnames.clear();


    // Get the hostname
    hostname[MAX_ADDR - 1] = '\0';
    if(gethostname(hostname, MAX_ADDR - 1) != 0)
    {
        ERROR_EXIT("Unable to get hostname of localhost");
    }

    hostnames.push_back(string(hostname));


    // Try and get the canonical hostname
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;        // use own IP address

    if((rv = getaddrinfo(hostname, NULL, &hints, &info)) != 0)
    {
        ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
    }

    for(p = info; p != NULL; p = p->ai_next)
    {
        if(p->ai_canonname)
        {
            hostnames.push_back(string(p->ai_canonname));
        }
    }

    freeaddrinfo(info);

    return hostnames;
}


// Return the location of the first occurence of a
// local hostname inside the node list
Node locate_local_node(vector<string>& hostnames, vector<Node>& nodes)
{
    // Find my address inside of the peer list
    bool found = false;
    Node self;
    for(size_t i = 0; i < nodes.size(); i++)
    {
        vector<string>::iterator p =
            find(hostnames.begin(), hostnames.end(), nodes[i].hostname);
        if(p != hostnames.end())
        {
            found = true;
            self = nodes[i];
            break;
        }
    }


    // Find location of hostname in list
    vector<Node>::iterator iter;

    if(found)
    {
        return self;
    }
    else
    {
        ERROR_EXIT("Unable to locate local host in the configuration file");
        return self;
    }
}


//Returns the process number 0-3 which contains the node
int get_next_process(int next_id, int next_level)
{
    if(next_id < 15)
        return (next_level % 4);

    if((next_id >= 15 && next_id <= 18) ||
        (next_id >= 31 && next_id <= 38))
        return 0;

    if((next_id >= 19 && next_id <= 22) ||
        (next_id >= 39 && next_id <= 46))
        return 1;

    if((next_id >= 23 && next_id <= 26) ||
        (next_id >= 47 && next_id <= 54))
        return 2;

    if((next_id >= 27 && next_id <= 30) ||
        (next_id >= 55 && next_id <= 62))
        return 3;

    return -1;
}

// called when QUERY message is received, level initially 0
int* search_for_value(int message_type, int key, int value, int requester_id, int current_node_id, int current_level)
{
    //some math required to crawl down tree
    int left_cmpval = (int)(1000000 / pow((double)2, current_level + 1));
    int left_id = (int)(pow((double)2, current_level)) - 1;
    int key_cmpval = (2 * (current_node_id - left_id) + 1) * left_cmpval;

    int* message = new int[5];
    int next_id, next_level;
    int offset, previous_level;

     //if id out of range, return empty message
    if(current_node_id < 0 || current_node_id > 62)
    {
	message[0] = -1;
        return message;
    }
	
    //At bottom of tree, access leaves
    if(current_level == 5)
    {
        switch(message_type)
        {
            case QUERY:
		//grab value from data array at offset
                offset = key - (31250 * (current_node_id - left_id));
                previous_level = current_level-1;
		//return value back up the tree       
                message[0] = RETURN_VALUE;
                message[1] = g_bst_nodes[current_node_id].data[offset]; //value
                message[2] = requester_id;
                message[3] = g_bst_nodes[current_node_id].parent_id;//send up to parent node
                message[4] = previous_level; //parent node is at previous level
                return message;
                break;

            case INSERT:
		 //put 'value' into the data array at offset
                 offset = key - (31250 * (current_node_id - left_id));
                 g_bst_nodes[current_node_id].data[offset] = value;
		//print the absolute time so insert latency can be calulated be hand
                 struct timeval t2;
                 gettimeofday(&t2, NULL);
                 cout << "Value " << value << " successfully inserted at key " <<
                    key << " in node " << current_node_id << endl;
                 cout << "Finished INSERT at " << t2.tv_sec << " seconds and " <<
                     t2.tv_usec << " useconds" << endl;
		//return done so no message is sent
                 message[0] = DONE;
                 return message;
                 break;

            case DELETE:
		//set the data array at location offset to 0
                offset = key - (31250 * (current_node_id - left_id));
                g_bst_nodes[current_node_id].data[offset] = 0;
                cout << "Value at key " << key << " successfully deleted " <<
                " from node " << current_node_id << endl;
		//return done so no message is sent
                message[0] = DONE;
                return message;
                break;

            default:
                cout << "Bad message type." << endl;
                break;
        }
    }

    //move to left child
    else if(key <= key_cmpval)
    {
	//get the child and level to move to next
        next_id = g_bst_nodes[current_node_id].left_id;
        next_level = current_level+1;
     
        //fill in message based on message type
        switch(message_type)
        {
            case QUERY:
                message[0] = QUERY;
                message[1] = key;
                message[2] = requester_id;
                message[3] = next_id;
                message[4] = next_level;  
                break;
            case INSERT:
                message[0] = INSERT;
                message[1] = key;
                message[2] = value;
                message[3] = next_id;
                message[4] = next_level;
                break;
            case DELETE:
                message[0] = DELETE;
                message[1] = key;
                message[2] = next_id;
                message[3] = next_level;
                break;
            default:
                break;
        }

        return message;
    }

    //move to the right child
    else if(key > key_cmpval)
    {
	//get child id and level to move to next
        next_id = g_bst_nodes[current_node_id].right_id;
        next_level = current_level+1;
            
        //fill in message based on message type
        switch(message_type)
        {
            case QUERY:
            message[0] = QUERY;
            message[1] = key;
            message[2] = requester_id;
            message[3] = next_id;
            message[4] = next_level;  
            break;  
        case INSERT:
            message[0] = INSERT;
            message[1] = key;
            message[2] = value;
            message[3] = next_id;
            message[4] = next_level;
            break;
        case DELETE:
            message[0] = DELETE;
            message[1] = key;
            message[2] = next_id;
            message[3] = next_level;
            break;  
        default:
            break;
        }      

        return message;
    } 
  
    //hopefully it never gets here
    else
    {
        return message;
    }

    return message;
}


//used to find parent and fill message to move the queried value back up the tree
int* return_value(int value, int requester_id, int current_node_id, int current_level)
{
       int* message = new int[5];

       message[0] = RETURN_VALUE;
       message[1] = value;
       message[2] = requester_id;
       message[3] = g_bst_nodes[current_node_id].parent_id;
       message[4] = current_level - 1;

       return message;
}


/*
 * Dispatch all auxillary threads here
 */
void dispatch_threads(const Node& self)
{
    int ret;

    // Spawn I/O thread
    pthread_t io_thread_id;
    IOArgs io_args;
    io_args.self = self;

    ret = pthread_create(&io_thread_id, NULL, io_start, (void *)&io_args);
    if(ret != 0)
    {
        ERROR_EXIT("Unable to spawn receiver thread");
    }

    // Spawn listener thread
    pthread_t listener_thread_id;
    ListenerArgs args;
    args.self = self;

    ret = pthread_create(&listener_thread_id, NULL, listener_start, (void *)&args);
    if(ret != 0)
    {
        ERROR_EXIT("Unable to spawn receiver thread");
    }



    // Join I/O thread
    ret = pthread_join(io_thread_id, NULL);
    if(ret != 0)
    {
        ERROR_EXIT("Unable to join receiver thread");
    }

    // Join listener thread
    ret = pthread_join(listener_thread_id, NULL);
    if(ret != 0)
    {
        ERROR_EXIT("Unable to join receiver thread");
    }
}


//Used to subtract two time values to get the latency between them
struct timeval timeval_difference(struct timeval tv1, struct timeval tv2) {
  struct timeval retval;
  retval.tv_sec=tv1.tv_sec-tv2.tv_sec;
  if (tv1.tv_usec<tv2.tv_usec) {
     tv1.tv_usec+=1000000;
     tv1.tv_sec--;
  }

  retval.tv_usec=tv1.tv_usec-tv2.tv_usec;
  return retval;
}



/*
 * Start point for the I/O thread
 * Provides an interactive loop for the user
 */
void* io_start(void* arg)
{
    int sockfd;
    struct addrinfo hints;
    struct addrinfo* servinfo;
    struct addrinfo* p;
    int rv;
    int numbytes;
    struct sockaddr_storage their_addr;
    int message[2];
    socklen_t addr_len;

    // Unpack arguments
    IOArgs args = *(IOArgs*)arg;

//Sets up the socket
/*********************************************************************************/
            memset(&hints, 0, sizeof hints);
            hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
            hints.ai_socktype = SOCK_DGRAM;
            hints.ai_flags = AI_PASSIVE; // use my IP

            if ((rv = getaddrinfo(NULL, IOPORT, &hints, &servinfo)) != 0) {
                ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
            }

            // loop through all the results and bind to the first we can
            for(p = servinfo; p != NULL; p = p->ai_next) {
                if ((sockfd = socket(p->ai_family, p->ai_socktype,
                        p->ai_protocol)) == -1) {
                    perror("listener: socket");
                    continue;
                }

                if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
                    close(sockfd);
                    perror("listener: bind");
                    continue;
                }

                break;
            }

            if (p == NULL) {
                ERROR_EXIT("Listener: failed to bind socket");
            }

            freeaddrinfo(servinfo);
/**********************************************************************************/

    string input;
    // Interactive loop
    while(true)
    {
	//sleep to give time for command to be completed
        usleep(100000);

	//get the next command from user
        getline(cin, input);

        // Tokenize the string
        istringstream iss(input);
        vector<string> tokens;
        copy(istream_iterator<string>(iss),
                istream_iterator<string>(),
                back_inserter< vector<string> >(tokens));


	//command must be 2 or 3 words
        if(tokens.size() < 2 || tokens.size() > 3)
        {
            cout << "Unknown command" << endl;
            continue;
        }

	
        string command = tokens[0];
        
	int key;
        stringstream ss(tokens[1]);
        ss >> key;
    
	//if insert, get value
	int value;
    	if(tokens.size() == 3)
    	{
            stringstream ss(tokens[2]);
            ss >> value;
    	}

        if(tokens[0] == "query")
        {
            struct timeval t1;
            struct timeval t2;
            // CHECK INPUT
            if(key < 0 || key > 1000000)
            {
                cout << "Key must be in range [0, 1,000,000]" << endl;
                continue;
            }

            cout << "EXECUTING QUERY ON " << tokens[1] << endl;
	    //save starting time
            gettimeofday(&t1, NULL);

	    //send instruction to first node
            submit_instruction(QUERY,args.self, g_nodes[0], key, 0);

	     //Wait for query response
            addr_len = sizeof their_addr;
            //cout << "Listening on IO port" << endl;
            if ((numbytes = recvfrom(sockfd, message, sizeof message , 0,
                (struct sockaddr *)&their_addr, &addr_len)) == -1) {
                ERROR_EXIT("Listener could not recvfrom");
            }
	 
            //save the time query was complete
            gettimeofday(&t2, NULL);

        cout << "****************************" << endl;
            cout << "RECEIVED VALUE = " << message[1] << endl;
            //get query latency = start time - complete time
            struct timeval diff = timeval_difference(t2, t1);
            double seconds;
            seconds = diff.tv_sec;
            seconds += (diff.tv_usec / 1000000.0);
            cout << "QUERY TOOK " << seconds << " seconds" << endl;
        cout << "****************************" << endl;

        }
        else if(tokens[0] == "insert")
        {
            // CHECK INPUT
            if(key < 0 || key > 1000000)
            {
                cout << "Key must be in range [0, 1,000,000]" << endl;
                continue;
            }
            cout << "EXECUTING INSERT ON " << tokens[1] << endl;
		
	    //print time instert was started so insert latency can be caluclated by hand
            struct timeval t1;
            gettimeofday(&t1, NULL);
            cout << "Started INSERT at " << t1.tv_sec << " seconds and " << 
                t1.tv_usec << " useconds" << endl;

	    //send instruction to first top node
            submit_instruction(INSERT,args.self, g_nodes[0], key, value);
        }
        else if(tokens[0] == "delete")
        {
            // CHECK INPUT
            if(key < 0 || key > 1000000)
            {
                cout << "Key must be in range [0, 1,000,000]" << endl;
                continue;
            }
            //cout << "EXECUTING INSERT ON " << tokens[1] << endl;
            cout << "EXECUTING DELETE ON " << tokens[1] << endl;
            //send delete message to top node
	    submit_instruction(DELETE,args.self, g_nodes[0], key, 0);
        }
        else
        {
            cout << "Unknown command" << endl;
            continue;
        }
    }

    return NULL;
}


/*
 * Start point for the listener thread
 * Waits for incoming network traffic
 * sends to search_for_value to create a new message
 * then sends out the message returned by search_for_value
 */
void* listener_start(void* arg)
{
    int sockfd, sd;
    struct addrinfo hints;
    struct addrinfo* servinfo;
    struct addrinfo* p, *q;
    int rv;
    int numbytes;
    struct sockaddr_storage their_addr;
    int message[3];
    socklen_t addr_len;

    struct sockaddr_storage io_addr;
    socklen_t io_addr_len;

    // Unpack arguments
    ListenerArgs args = *(ListenerArgs*)arg;

//Set up the socket
/**************************************************************/
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE; // use my IP

    if ((rv = getaddrinfo(NULL, PORT, &hints, &servinfo)) != 0) {
        ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
    }

    // loop through all the results and bind to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
                p->ai_protocol)) == -1) {
            perror("listener: socket");
            continue;
        }

        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("listener: bind");
            continue;
        }

        break;
    }

    if (p == NULL) {
        ERROR_EXIT("Listener: failed to bind socket");
    }

    freeaddrinfo(servinfo);

   sd = sockfd;
  q = p;
/////////////////////////////////////////////////////////////

    while(true)
    {
        //cout << "waiting on recvfrom..." << endl;
        addr_len = sizeof their_addr;
        if ((numbytes = recvfrom(sd, message, 5*sizeof(int) , 0,
            (struct sockaddr *)&their_addr, &addr_len)) == -1) {
            ERROR_EXIT("Listener could not recvfrom");
        }

        //cout << "Received data, length = " << numbytes << ", contents = " << message[0] << " " << message[1]<<" " << message[2]<< " " << message[3]<<" "<< message[4]<< endl;

        int current_level, key, value;
 	int next_level, next_id;
    	int requester_id, current_id;
   	int* returned_message = (int*)malloc(5*sizeof(int));
    	char* ip = (char*)malloc(50);
    	char port[5];

	//Switch based on type of message received
        switch(message[0])
        {
            case QUERY:
                key = message[1];
        	requester_id = message[2];
        	current_id = message[3];
        	current_level = message[4];

		//seach_for_value handles this message and returns the next one to be sent out
		memcpy(returned_message, search_for_value(QUERY, key, 0, requester_id, current_id, current_level), 5*sizeof(int));
		
		next_id = returned_message[3];
		next_level = returned_message[4];

		//get the ip address of the process we are sending to
		strcpy((char*)ip, g_nodes[get_next_process(next_id, next_level)].hostname.c_str());

	      	//ip = inet_ntoa(((sockaddr_in*)(struct sockaddr*)&their_addr)->sin_addr);
	
		if(returned_message[0] == QUERY)
		    cout << "Sending QUERY to Node: " << next_id << endl;
		else if(returned_message[0] == RETURN_VALUE)
		    cout << "Sending Return Value to Node:" << next_id << endl;

		//fill in struct with ip and port info
		 if ((rv = getaddrinfo(ip, PORT, &hints, &servinfo)) != 0) {
			ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
		 }

		 for(p = servinfo; p != NULL; p = p->ai_next) {
		    break;
		 }
	 
		//cout << "SENDING after recv query, length = " << numbytes << ", contents = " << returned_message[0] << " " << returned_message[1]<<" " << returned_message[2]<< returned_message[3]<<" "<< returned_message[4]<< endl; 
                
		//send message to next node
		if((numbytes = sendto(sockfd, returned_message, 5*sizeof(int), 0, p->ai_addr, p->ai_addrlen)) == -1)
                {
                    cout << "sockfd = " << sockfd << endl;
                    cout << strerror(errno) << endl;
                    ERROR_EXIT("sendto failed");
                }

                io_addr = their_addr;
                io_addr_len = addr_len;

               // cout << "[Listener] Send RETURN_VALUE to IO Thread" << endl;
                break;
            

	   case INSERT:
        	key = message[1];
        	value = message[2];
		current_id = message[3];
		current_level = message[4];
		//search_for_value handles received message, returns message to be sent
		memcpy(returned_message,  search_for_value(INSERT, key, value, 0, current_id, current_level), 5*sizeof(int));
	
		//if value was inserted, no need to send another message
		if(returned_message[0] == DONE) break;

		next_id = returned_message[3];
		next_level = returned_message[4];
		cout << "Inserting: "<< key <<" send to node: "<<next_id << endl;

		//get ip of process that contains the next node
		strcpy((char*)ip, g_nodes[get_next_process(next_id, next_level)].hostname.c_str());

		//fill in ip and port for the process with next node
		if ((rv = getaddrinfo(ip, PORT, &hints, &servinfo)) != 0) {
			ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
		}

		for(p = servinfo; p != NULL; p = p->ai_next) {
		    break;
		}
 
            //cout  << " contents = " << returned_message[0] << " " << returned_message[1]<<" " << returned_message[2]<< returned_message[3]<<" "<< returned_message[4]<< endl<<endl; 
                
		//send Insert message to next node
		if((numbytes = sendto(sockfd, returned_message, 5*sizeof(int), 0, p->ai_addr, p->ai_addrlen)) == -1)
                {
                    cout << "sockfd = " << sockfd << endl;
                    cout << strerror(errno) << endl;
                    ERROR_EXIT("sendto failed");
                }

                io_addr = their_addr;
                io_addr_len = addr_len;
                break;


            case DELETE:
		key = message[1];
		current_id = message[2];
		current_level = message[3];
		//search_for_value handles received message, returns next message to send
		memcpy(returned_message,  search_for_value(DELETE, key, 0, 0, current_id, current_level), 5*sizeof(int));
		
		//if delete complete, no need to send another message
		if(returned_message[0] == DONE) break;

		next_id = returned_message[2];
		next_level = returned_message[3];
		cout << "DELETING: "<< key <<" send to node: "<<next_id << endl;
		
		//get ip of process that contains the next node
		strcpy((char*)ip, g_nodes[get_next_process(next_id, next_level)].hostname.c_str());

		//set up ip and port for message send
		if ((rv = getaddrinfo(ip, PORT, &hints, &servinfo)) != 0) {
			ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
		}

		for(p = servinfo; p != NULL; p = p->ai_next) {
		    break;
		}
 
            //cout  << " contents = " << returned_message[0] << " " << returned_message[1]<<" " << returned_message[2]<< returned_message[3]<<" "<< returned_message[4]<< endl<<endl; 
                
		//send message to next node
		if((numbytes = sendto(sockfd, returned_message, 5*sizeof(int), 0, p->ai_addr, p->ai_addrlen)) == -1)
                {
                    cout << "sockfd = " << sockfd << endl;
                    cout << strerror(errno) << endl;
                    ERROR_EXIT("sendto failed");
                }

                io_addr = their_addr;
                io_addr_len = addr_len;
                break;


            case RETURN_VALUE:
                value = message[1];
		requester_id = message[2];
		current_id = message[3];
		current_level = message[4];
		//return_value() handles received message, returns next message to send
		memcpy(returned_message,  return_value(value, requester_id, current_id, current_level), 5*sizeof(int));
		
		next_id = returned_message[3];
		next_level = returned_message[4];

		cout << "[Listener] received a RETURN_VALUE - SENDING to " << next_id << endl;

		//if current level is 0, send to IO of requestor process
		if(message[4] == 0)
		{
		    strcpy((char*)ip, g_nodes[message[2]].hostname.c_str()); //get hostname of requester process
		    sprintf(port, IOPORT);
		}
		else //send to next node in tree
		{
		    strcpy((char*)ip, g_nodes[get_next_process(next_id, next_level)].hostname.c_str());
		    sprintf(port, PORT);
		}

		//set up ip and port for next message send
		if ((rv = getaddrinfo(ip, port, &hints, &servinfo)) != 0) {
			ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
		}

		for(p = servinfo; p != NULL; p = p->ai_next) {
		    break;
		}
 
            //cout  << " contents = " << returned_message[0] << " " << returned_message[1]<<" " << returned_message[2]<< returned_message[3]<<" "<< returned_message[4]<< endl; 
                
		//send message to next node
		if((numbytes = sendto(sockfd, returned_message, 5*sizeof(int), 0, p->ai_addr, p->ai_addrlen)) == -1)
                {
                    cout << "sockfd = " << sockfd << endl;
                    cout << strerror(errno) << endl;
                    ERROR_EXIT("sendto failed");
                }

                io_addr = their_addr;
                io_addr_len = addr_len;
                break;
            

	    default:
                ERROR_EXIT("Invalid message format");
        }
    }


    return NULL;
}


//sends instruction from initial request to top node of tree
int submit_instruction(int type, Node& self, Node& root, int key, int value)
{
    int sockfd;
    struct addrinfo hints, *servinfo, *p;
    int rv;
    int numbytes;
    int message[5];

//Set up new socket for each send
/***************************************************************/
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;

    if ((rv = getaddrinfo(root.hostname.c_str(), PORT, &hints, &servinfo)) != 0) {
        ERROR_EXIT("getaddrinfo: " + string(gai_strerror(rv)));
    }

    // loop through all the results and make a socket
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
                p->ai_protocol)) == -1) {
            perror("talker: socket");
            continue;
        }

        break;
    }

    if (p == NULL) {
        ERROR_EXIT("Failed to bind socket");
    }
/****************************************************************/

//create message base in instruction type
    switch(type)
    {
      case QUERY:
	     message[0] = QUERY;
	     message[1] = key;
	     message[2] = self.id;
	     message[3] = 0;
	     message[4] = 0;
 	     break;
      case INSERT:
	     message[0] = INSERT;
	     message[1] = key;
	     message[2] = value;
	     message[3] = 0;
	     message[4] = 0;
             break;
      case DELETE:
     	     message[0] = DELETE;
             message[1] = key;
             message[2] = 0;
     	     message[3] = 0;
     	     message[4] = 0;
             break;
    }

    //send message to root of tree
    if ((numbytes = sendto(sockfd, message, sizeof message, 0,
            p->ai_addr, p->ai_addrlen)) == -1) {
        ERROR_EXIT("Failed to submit the query");
    }

    //done with socket, close it
    close(sockfd);

    return key;
}


// Main entrance point
int main(int argc, char **argv)
{
    //vector<Node> nodes;
    Node self;


    // Parse the command line arguments
    if(argc != 2)
    {
        usage();
        exit(1);
    }

    // Read in node info from file
    g_nodes = parse_config(argv[1]);
    cout << "[MyKV] Nodes in the system:" << endl;
    for(vector<Node>::size_type i = 0; i < g_nodes.size(); ++i)
    {
        cout << g_nodes[i] << endl;
    }
    cout << endl;


    // Get local hostname
    local_hostnames = gethostnames();
    cout << "[MyKV] Local hostnames available:" << endl;
    for(vector<Node>::size_type i = 0; i < local_hostnames.size(); i++)
    {
        cout << local_hostnames[i] << endl;
    }
    cout << endl;

    // Find local node in node list
    self = locate_local_node(local_hostnames, g_nodes);
    g_id = self.id;
    cout << "Located self: " << endl;
    cout << self << endl;
    cout << endl;


    // Initialize the BST
    initialize_bst_nodes(self.id);
    cout << "Node " << self.id << " contains:" << endl;
    for(map< int, BSTNode<int> >::iterator p = g_bst_nodes.begin();
            p != g_bst_nodes.end();
            ++p)
    {
        cout << p->first << endl;
    }


    // Start the auxillary threads
    dispatch_threads(self);

    printf("[MyKV] Exiting...\n");
    return 0;
}

