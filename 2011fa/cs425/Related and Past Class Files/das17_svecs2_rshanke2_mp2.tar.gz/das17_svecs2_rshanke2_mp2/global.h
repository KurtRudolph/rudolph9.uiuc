#ifndef GLOBAL_H_
#define GLOBAL_H_

#include <stdint.h>
#include <ctime>
#include <sys/time.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <cstdlib>
#include <signal.h>
#include <iostream>
#include <fstream>
#include <cmath>
#include <map>
#include <vector>
#include <list>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <limits>
#include <sched.h>

const bool debugRun=false;

using namespace std;
// global defines and structures used by all classes

// simple macros - may need to improve/replace later - e.g. add logging / error codes
#define FAIL(msg) do { cerr << msg << endl; exit(EXIT_FAILURE); } while(0);
#define FAIL_THREAD(msg) do { cerr << msg << endl; pthread_exit(NULL); } while(0);
#define DEBUG_MSG(msg) do{ if(debugRun) cerr << msg << endl;} while(0);
#define LOG_MSG(msg) do{ cout << msg << endl; }while(0);

		
#define MAX_NUM_RETRIES_TO_CONNECT (15)	// num of possible tries
#define CONNECTION_RETRY_INTERVAL 	(5)	// num of seconds to elapse before retrying

#define CLIENT_GET_REQUEST (0)
#define CLIENT_PUT_REQUEST (1)
#define CLIENT_DELETE_REQUEST (2)

typedef uint8_t  m_id_t ;	// Assuming only 255 machines
typedef uint32_t keytype_t ;



// structure of a client request packet  
// in case of PUT we will have two further fields to follow
// uint32_t put-length and (put-length) sized contents
struct RequestPacket {
   uint8_t reqType;   // Request type  (can be either CLIENT_PUT_REQUEST or CLIENT_GET_REQUEST 
   uint8_t level;			// level to which this packet is sent
   uint8_t index;			// index within that level to which the packet is sent
   uint16_t clientPort;		// Client port
   uint16_t transId;		// Transaction id to disambiguate at client side
   uint32_t key;            // Key to GET or PUT
   uint32_t clientAddr;		// Client Addr
};

// The response will consist of length followed by <length> number of bytes
struct ResponsePacket{
    uint16_t length;
	uint16_t transId;		// Transaction id to disambiguate at client side
};

// Utility function used to tokenize strings
void Tokenize(const string& str, vector<string>& tokens, const string& delimiters = " \t");
#endif /* GLOBAL_H_ */
