

let report x =
   print_string "Result: ";
   print_int x;
   print_newline();;

