#include  "../global.h"

/* A simple client utility that sends get/put requests to the server
   Arguments
       ./KVClient server port-number GET/PUT  Key <optional put-string>

   
*/


// Utility function used to tokenize strings
void Tokenize(const string& str, vector<string>& tokens, const string& delimiters) 
{
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}

const char *localIp="127.0.0.1";
//const uint16_t localPort = 35000;

int SendClientRequest(RequestPacket reqPacket,int fd)
{
    int nr = send(fd,&reqPacket,sizeof(reqPacket),MSG_NOSIGNAL);
    if( nr < (int) sizeof(nr) )
    {
        DEBUG_MSG("Cannot send request packet ");
        return -1;
    }
    return 0;
}



int main(int argc, char *argv[])
{

    if(argc < 6)
    {
        cerr << "Incorrect number of arguments "<< endl
            << "USAGE: ./KVClient server port-number localPort transId GET/PUT/DEL  Key <optional put-string>" << endl;
    }

    string serverName = argv[1];
    int port = atoi(argv[2]);
    uint16_t localPort = atoi(argv[3]);
	uint16_t transId = atoi(argv[4]);
    string reqType = argv[5];
    int key = atoi(argv[6]);

    struct sockaddr_in servAddr;
    struct hostent *servEnt;

    int listenFD = socket(AF_INET,SOCK_STREAM,0);
    if( listenFD < 0)
        FAIL("Error opening listening socket");

    // our socket address
    struct sockaddr_in listenAddr;
    memset(&listenAddr,0,sizeof(listenAddr));
    listenAddr.sin_family = AF_INET;
    listenAddr.sin_port = htons(static_cast<uint16_t>(localPort));
    listenAddr.sin_addr.s_addr = INADDR_ANY;

	if(bind(listenFD, (struct sockaddr *)&listenAddr, sizeof(listenAddr)) < 0) {
		FAIL("could not bind()");
	}
    //  Have to verify that (mNumServerThreads * 2) is a good backlog limit or not
	if(listen(listenFD, 1000) < 0) {
		FAIL("could not listen()");
	}
	int on = 1;
	setsockopt(listenFD, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));


	
    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    if( sockfd < 0)
        FAIL("Error opening socket");
    servEnt = gethostbyname(serverName.c_str());
    if (servEnt == NULL) {
        FAIL("Cannot find server");
    }
    bzero((char *) &servAddr, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    bcopy((char *)servEnt->h_addr, (char *)&servAddr.sin_addr.s_addr,servEnt->h_length);
    servAddr.sin_port = htons(port);

    if (connect(sockfd,(struct sockaddr *)&servAddr,sizeof(servAddr)) < 0) 
        FAIL("Cannot connect to server");

	DEBUG_MSG("Connected to server");

	struct sockaddr_in sa;
	inet_pton(AF_INET, localIp, &(sa.sin_addr));


    struct RequestPacket req;
	req.clientAddr = (in_addr_t)sa.sin_addr.s_addr;
	req.clientPort = localPort;
	req.level = 1;
	req.index = 1;
	req.transId = transId;	


    if( (reqType=="GET") || (reqType == "DEL" ) )
    {
		if( reqType == "GET") 
        	req.reqType = CLIENT_GET_REQUEST;
		else
			req.reqType = CLIENT_DELETE_REQUEST;
        req.key = key;
        int n = SendClientRequest(req,sockfd);
		DEBUG_MSG("SENT  GET/DEL request bytes " << sizeof(req) );
        if( n != 0 )
            FAIL("Cannot write to server");
        DEBUG_MSG("Total bytes written " << n);
    }else
    if(reqType=="PUT")
    {
        if(argc < 7)
            FAIL("Put message not given");

        req.reqType = CLIENT_PUT_REQUEST;
        req.key = key;

        int n = send(sockfd,(char*)&req,sizeof(req),0);
        if( n < (int)sizeof(req))
            FAIL("Cannot write to server");
    }
	else
	{
		DEBUG_MSG("UNKNOWN Message" << reqType );
	}
    LOG_MSG("Request Sent");
    close(sockfd);



    struct sockaddr_in callerId;
    socklen_t sockLength;
    sockLength = sizeof(sockaddr);

    DEBUG_MSG("Waiting for response from server");
    if((sockfd=accept(listenFD,(struct sockaddr*)&callerId,&sockLength)) == -1) {
        FAIL_THREAD("Could not accept incoming connections from server");
    }
    //RequestPacket clientReq;
    //int nRead=recv(fd,&clientReq,readSize,0);
    char buf[INET_ADDRSTRLEN];
    inet_ntop(AF_INET,&(callerId.sin_addr),buf,INET_ADDRSTRLEN);
    DEBUG_MSG("Found a incoming connection: From " << buf << " Port " << callerId.sin_port);

    if(req.reqType == CLIENT_PUT_REQUEST )
    {
        char resp;
        int nr = recv(sockfd,&resp,1,0);
        if( nr < 1)
            FAIL_THREAD("Error didn't recieve response from server");
        uint32_t putLength = strlen(argv[7]);
        nr = send(sockfd,(char *)&putLength,sizeof(putLength),MSG_NOSIGNAL);
        if(nr < (int)sizeof(putLength) )
            FAIL("Cannot write to server");
        nr = send(sockfd,argv[7],putLength,0);
        if( nr < (int)putLength)
            FAIL("Cannot write to server");
		DEBUG_MSG("SENT  PUT request ");
    }


    struct ResponsePacket respPacket;
    int n = recv(sockfd,(char *)&respPacket,sizeof(respPacket),0);
    if( n < (int) sizeof(respPacket))
        FAIL("Cannot read response from server");
    if(respPacket.length > 0)
    {
        char *buf = new char[respPacket.length+1];
        n  = recv(sockfd,buf,respPacket.length,0);
        // TODO: Check if packet fragmentation can cause problems with large responses here
        if( n < respPacket.length )
            FAIL("Cannot read response from server");
        buf[respPacket.length]='\0';
        string response = buf;
        cout << " Found Value for Key " << key <<  "With transaction " << respPacket.transId << " as length " << respPacket.length << " value " << buf << endl;
    }
    else
        cout << "MyKV did not find the key " << endl; 

    close(sockfd);
}
