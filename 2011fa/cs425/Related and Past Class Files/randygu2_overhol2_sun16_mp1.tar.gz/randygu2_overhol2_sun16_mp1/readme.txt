README
MP1 - CS425

Group Members:
Randy Gu
Mark Overholt
James Sun

1. Running the Failure Detector:
	i.	Compiling:
		To compile the FD, on each machine, run the following command:
		
			gcc -lpthread spock.c -o spockFD
			
		Each machines needs a copy of the spockFD executable
	ii.	Running the spockFD:
		The spockFD requires 5 parameters. 
			
			./spockFD <MyProcessID> <HostName1> <HostName2> <ListenProcessID1> <ListenProcessID2>
			
		MyProcessID: The ProcessID of the host running the executable. This is arbitrarily defined
		HostName1: The first hostname to send heartbeats to
		HostName2: The second hostname to send heartbeats to
		ListenProcessID1: The first ProcessID to listen for heartbeats from
		ListenProcessID2: The second ProcessID to listen from heartbeats form
		
		Using the example configuration (Appendix A), here are the commands for running spockFD on the 4 machines
		
		host1.illinois.edu:
		./spockFD 1 host2.illinois.edu host4.illinois.edu 2 4
		
		host2.illinois.edu:
		./spockFD 2 host3.illinois.edu host1.illinois.edu 3 1
		
		host3.illinois.edu:
		./spockFD 3 host4.illinois.edu host2.illinois.edu 4 2
		
		host4.illinois.edu:
		./spockFD 4 host1.illinois.edu host3.illinois.edu 1 3

2. Running the 50% Message Loss Experiment:
	We included two extra source files that were used to run the 50% Message Loss experiment. 
	One host machine will run the 'spock_50p_message_loss.c' file.
	The other three host machines will run the 'spock_falsepositive_detector.c'
	
	i. Compiling
		gcc -lpthread spock_50p_message_loss.c -o spockFD_ML
		gcc -lpthread spock_falsepositive_detector.c -o spockFD_FPD
		
	ii. Running the Experiment:
		Using the example configuration (Appendix A), host1.illinois.edu will run the spockFD_ML program. 
		This will simulate a 50% message loss to those machines that it is sending its heartbeat to.
		
		The other 3 machines will be running the spockFD_FPD, which has some special code to keep track of False Positive Statistics. 
		
		Using the example configuration, here are the commands to run the Experiment:
		
		host1.illinois.edu:
		./spockFD_ML 1 host2.illinois.edu host4.illinois.edu 2 4
		
		host2.illinois.edu:
		./spockFD_FPD 2 host3.illinois.edu host1.illinois.edu 3 1
		
		host3.illinois.edu:
		./spockFD_FPD 3 host4.illinois.edu host2.illinois.edu 4 2
		
		host4.illinois.edu:
		./spockFD_FPD 4 host1.illinois.edu host3.illinois.edu 1 3

3. Source Code Description
	i.		spock.c:
		This is the main Failure Detection code. A copy is run on each host machine, but using different parameters. It spawn 3 threads. 1 Thread to listen to all incoming heartbeats, 
		and 2 Threads to send out heartbeats to listening hosts. Both the talker and the listener use UDP to communicate. 
		
		The Talker Threads each send a heartbeat message to their respecitve listener machines. These heartbeats are sent every 5 seconds. The message that is send contains both the
		ProcessID that is sending the message, and the MessageID. The MessageID is a number from 0-9. Once the MessageID reaches 9, it cycles back to 0. 
		
		The Listener Thread listens to all incoming heartbeats. It then compares the ProcessID in the message to a list of ProcessID's that it has been tasked to listen to. If the ID matches,
		and the MessageID is greater than the last message ID sent (In this method, 0 > 9, since a 0 ID would come after a 9, and assuming that it won't have missed 1-8 without failing), then
		the Listener updates a Time_To_Fail variable. In the off cycles when it is not processing a message (The socket is Non Blocking), it checks each host's Time_To_Fail variable and compares
		it with the system time. If the time to fail is greater than the now time, it declares that host as failed. 
	
	ii.		spock_50p_message_loss.c:
		This is an adaptation of spock.c. It does everything the original source file does. The only difference is that the talker simulates a 50% message loss.
		It does this by picking a random number between 1 and 100. If the number is greater than 50, it doesn't send a message, if it is less than 50, it does send a message.
		This simulates a random message loss of 50%. 
	
	iii.	spock_falsepositive_detector.c:
		This is an adaptation of spock.c also. It does everything the original source file does. This files only difference is that it allows multiple failures from 1 machines. This is to let
		us run the expirement across multiple False Positives, to obtain some statistics on False Positive Rate of this algorithm. 
	
	
Appendix A: Example Configuration:

host1.illinois.edu				host2.illinois.edu
	MMMMMM                          MMMMMM
	M    M                          M    M
	M  1 M<------------------------>M  2 M
	M    M                          M    M
	MMMMMM                          MMMMMM
	   ^							   ^
	   |							   |
	   |                               |
	   |                               |
	   |                               |
	   |                               |
	   v                               v
	MMMMMM                          MMMMMM
	M    M                          M    M
	M  4 M<------------------------>M  3 M
	M    M                          M    M
	MMMMMM                          MMMMMM
host4.illinois.edu				host3.illinois.edu

Four Machines (M), host1, host2, host3, and host4.illinois.edu each have the Spock failure detector running on them. The Arrows (->, <-, v, ^) point the direction of travel for the messages
Each machines also has a processID to be used in the Listening part of the FD. 


May each host "Live Long and Prosper"

___________________          _-_
\==============_=_/ ____.---'---`---.____
            \_ \    \----._________.----/
              \ \   /  /    `-_-'
          __,--`.`-'..'-_
         /____          ||
              `--.____,-'

