(* 
  CS421 - Summer 2011
  MP2 
*)

(* Problem 1 *)
let reverse_fst_trd a = failwith "not implemented"

(* Problem 2 *)
let square_dist a = failwith "not implemented"

(* Problem 3 *)
let first_two_pairs l1 l2 = failwith "not implemented"

(* Problem 4 *)
let rec sum l = failwith "not implemented"

(* Problem 5 *)
let rec collatz n = failwith "not implemented"

(* Problem 6 *)
let rec unzip l = failwith "not implemented"

(* Problem 7 *)
let rec dotproduct l1 l2 = failwith "not implemented"

(* Problem 8 *)
let rec partition x l = failwith "not implemented"

(* Problem 9 *)
let rec remove_all f l = failwith "not implemented"

(* Problem 10 *)
let mapidx f l = failwith "not implemented"

(* Extra Credit *)
(* Problem 11 *)
let rec group l = failwith "not implemented"
