(* CS421 
 * MP1 
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You will want to change how a number of these start.
 *)

open Mp1common

(* Problem 1 *)
let a = 0;;  (* You will want to change this. *)

(* Problem 2 *)
let s = "Something else you will want to change";;

(* Problem 3 *)
let add_a n =
  raise(Failure "Function not implemented yet.")

(* Problem 4 *)
let s_paired_with_a_times b =
  raise(Failure "Function not implemented yet.")

(* Problem 5 *)
let abs_diff x =
  raise(Failure "Function not implemented yet.")

(* Problem 6 *)
let greetings name =
  raise(Failure "Function not implemented yet.")

(* Problem 7 *)
let sign n =
  raise(Failure "Function not implemented yet.")

(*Problem 8 *)
let pre_post_compose p =
  raise(Failure "Function not implemented yet.")
