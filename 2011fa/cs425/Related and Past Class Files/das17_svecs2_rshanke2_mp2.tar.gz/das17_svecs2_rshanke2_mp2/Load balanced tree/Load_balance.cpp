/*
 * Load_balance.cpp
 *
 *  Created on: Oct 27, 2010
 *      Author: anupam
 */

#include "Load_balance.h"

struct node
{
	int machine;
	int level;
	int index;
	int value;
};

void Load_balance::Tokenize(const string& str, vector<string>& tokens, const string& delimiters = " ") const
{
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}


void Load_balance::ParseConfigFile(const string& configFile)
{
	ifstream file;

	file.open(configFile.c_str());
	if(!file) {
		cout<<"Could not open tree configuration file: "<<endl;
	}

	string line;
	while(getline(file, line)) {
		if(line.empty()) continue;
		vector<string> tokens;
		Tokenize(line, tokens);
		if(tokens.size() < 2 ) {
			continue; // wrong format
		}

		string& keyword = tokens[0];
		string& value = tokens[1];
		if(keyword == "Range") {
			Set_Range(atoi(value.c_str())); //setting the range of value
		}else if(keyword == "Levels") {
			Set_Level(atoi(value.c_str())); //setting number of levels
		} else if(keyword == "Machines") {
			Set_Number_Machine(atoi(value.c_str())); //setting the number of machines
		}else  {
			cout<<"Error in tree configuration file"<<endl;
		}
	}
	file.close();
	Init_Machine_load();

}

Load_balance::Load_balance(const string& configFile)
{
	//default values
	/*
	    Level = 5; // these values should not be used anyway...
	    Number_Machine= 4;
	    Machine_load=new int[Number_Machine];
	    for(int i=0;i<Number_Machine;i++)Machine_load[i]=0;
	    struct node tree[]=new struct node[int(pow(2,Level))-1];//total nodes in the tree except for the leafs->buckets

	*/
	    ParseConfigFile(configFile);
}


// destructor - clean up resources
Load_balance::~Load_balance(void)
{

}

void Load_balance::Calculate_Load_balance()
{
	ofstream output[Number_Machine];
	for(int i=0;i<Number_Machine;i++)
	{
		std::stringstream ss;
		ss<<"Output"<<(i+1)<<".txt";
		output[i].open(ss.str().c_str());

		if(!output[i])
		{
				cout<<"Could not open "<<i+1<<"th output tree configuration file."<<endl;
		}
		output[i]<<"#For Machine "<<i+1<<endl;

		output[i]<<"#keyword    Machine 	Level   Index   Key-Range  "
									"[LEFT] 	 Machine	Level	Index	Key-Range "
									"[RIGHT] 	 Machine	Level	Index	Key-Range " << endl;
	}

	node tree[int(pow(2,Level))-1];//total nodes in the tree except for the leafs->buckets

	int index=0;
	for(int i=1;i<=Level;i++)
	{
		for(int j=1;j<=int(pow(2,i-1));j++)
		{
			int temp=Calculate_minimum_load();//returns the index of the machine with lowest load
			Update_Machine_load(temp,int (pow(2,Level-i)));
			tree[index].machine=temp+1;//starting with machine 1 ...... 2,3,4
			tree[index].level=i; // level in tree
			tree[index].index=j; // index in a level ..... from left to right 1,2...,n
			tree[index].value=((2*j-1)*Range)/(int(pow(2,i))); // comparison value
			index++;
		}
	}


	int size=int(pow(2,Level-1))-1;

	for(int i=0;i<size;i++)
    {
    	output[tree[i].machine-1]<<"node\t"<<tree[i].machine<<"\t"<<tree[i].level<<"\t"<<tree[i].index<<"\t"<<tree[i].value<<"\t"
    			                <<"\t"<<tree[2*i+1].machine<<"\t"<<tree[2*i+1].level<<"\t"<<tree[2*i+1].index<<"\t"<<tree[2*i+1].value<<"\t"
    			                <<"\t"<<tree[2*i+2].machine<<"\t"<<tree[2*i+2].level<<"\t"<<tree[2*i+2].index<<"\t"<<tree[2*i+2].value
    			                <<endl;
		// Now check if any of the left or right nodes are leaf level nodes
		// If so populate their information in the appropriate output file
		if( tree[2*i+1].level == Level )
    		output[tree[2*i+1].machine-1]<<"node\t"<<tree[2*i+1].machine<<"\t"<<tree[2*i+1].level<<"\t"<<tree[2*i+1].index<<"\t"<<tree[2*i+1].value<<endl;
		if( tree[2*i+2].level == Level )
    		output[tree[2*i+2].machine-1]<<"node\t"<<tree[2*i+2].machine<<"\t"<<tree[2*i+2].level<<"\t"<<tree[2*i+2].index<<"\t"<<tree[2*i+2].value<<endl;
    }

	for(int i=0; i<Number_Machine;i++)
	{
		output[i]<<"#Total Machine load="<<Machine_load[i];
	}

}

int Load_balance::Calculate_minimum_load()
{
	int tp=INT_MAX;
	int id=0;
	for(int i=0;i<Number_Machine;i++)
	{
		if(tp>Machine_load[i]){tp=Machine_load[i];id=i;}
	}
	return id;
}

