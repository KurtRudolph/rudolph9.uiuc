#ifndef KVSERVER_H  // [
#define KVSERVER_H
#include "../global.h"

using namespace std;

const int DEFAULT_LEAF_LEVEL = 6;			 // Level where leaves start (this means we have 1 till 5 internal nodes)
const int DEFAULT_NUM_SERVER_THREADS = (10); // default number of client servicing threads to start
const int DEFAULT_NUM_MACHINES = (4);
struct MachineAddr {
    string hostName;
    int port;
};

struct ChildNode {
    m_id_t machineNum;      // machine to which we should re-direct the request
    int level;              // the level on that target machine where the internal node is
    int index;              // the index on the level which corresponds to the internal node
};

struct InternalNode {
    keytype_t key;              // Key on which this node decides
    ChildNode left;     // Left child
    ChildNode right;    // Right child
};

struct LeafNode{
    keytype_t key;              // Key on which this node decides
    
    pthread_mutex_t leftLock;
    map<int,char*> leftBin;     // Left Bin
    pthread_mutex_t rightLock;
    map<int,char*> rightBin;    // Right Bin 
};



class KVServer 
{
    private:
        int mNumServerThreads;   // Number of concurrent threads servicing requests
        void ParseConfigFile(const string&);

        // Id corresponding to this machine
        m_id_t mId;
        // Port on which we are listening on
        int mPort;
        // Total number of machines in the system (including ourself)
        int mTotalMachines;
		// Leaf level (our levels start with 1)
		int mLeafLevel;

        // socket that we are listening on
        int mSrvSock;
        // our socket address
        struct sockaddr_in mSrvSockAddr;




        // Handles client requests to Get and Put keys in Key-Value store
        static void *HandleRequest(void *);

        //map<int,MachineAddr *>  machineMap; 
        MachineAddr **machineAddrMap;// Maps a given machine-id to its MachineAddr (consisting of host-id,port)
        int *mPeerSocks;

        // Given a (level,index), we find out the internal node corresponding to that level,index
        // Each machine only keeps the entries corresponding to the internal nodes (within the binary tree)
        // which are hosted on its machine.
        map< pair<int,int> , InternalNode *>  mInternalNodes;   

        // Given a (level,index), we find out the final leafLevel node
        map< pair<int,int> , LeafNode*>  mLeafNodes;   

        void RedirectPackage(m_id_t,RequestPacket);  // Redirect the given request to the given machine
        void HandleGetRequest(RequestPacket);
        void HandlePutRequest(RequestPacket);
        void HandleDeleteRequest(RequestPacket);
        


    public:
        // Constructor for the server
        KVServer(const string& configFile);
        // Creates server socket
        void CreateServerSocket(void);
        void CreatePeerSockets(void);
        // Listens to incoming connections
        void Run(void);
        // Adds neighbor entries  essentially a machine-id to address mapping
        void AddNeighborEntry(int ,string&,int);
};

struct ThreadEntry {
    int id;         // thread id
    KVServer *pServer;  // pointer to thread object
};


#endif              // ]
