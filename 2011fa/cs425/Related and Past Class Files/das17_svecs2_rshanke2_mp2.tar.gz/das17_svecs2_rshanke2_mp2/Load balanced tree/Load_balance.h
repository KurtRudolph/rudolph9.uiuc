/*
 * Load_balance.h
 *
 *  Created on: Oct 27, 2010
 *      Author: anupam
 */

#ifndef LOAD_BALANCE_H_
#define LOAD_BALANCE_H_


#include <string>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <cmath>
#include <climits>


using namespace std;



class Load_balance
{

public:
	Load_balance(const string& configFile);
    ~Load_balance(void);

    void Tokenize(const string& str, vector<string>& tokens, const string& delimiters) const;
    void ParseConfigFile(const string& configFile);

    //parameter set
    void Set_Range(int r){this->Range=r;}
    void Set_Level(int l){this->Level=l;}
    void Set_Number_Machine(int n){this->Number_Machine=n;}
    void Init_Machine_load(){this->Machine_load=new int[Number_Machine];for(int i=0;i<Number_Machine;i++)Machine_load[i]=0;}
    void Update_Machine_load(int index,int val){this->Machine_load[index]=this->Machine_load[index]+val;}

    void Calculate_Load_balance(); // do calculation
    int Calculate_minimum_load();
    void PrintState(void) const;

protected:
    int Range,Level,Number_Machine;//parameters discussed in the relevant paper.
    int* Machine_load;


};






#endif /* LOAD_BALANCE_H_ */
