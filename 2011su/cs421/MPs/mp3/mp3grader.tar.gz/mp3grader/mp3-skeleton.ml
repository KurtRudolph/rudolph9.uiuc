(* CS 421 Summer 2011 MP3 *)

open Mp3common

(* Problem 1 *)
let rec polar_to_cart lst = raise(Failure "Function not implemented yet.")

(* Problem 2 *)
let rec determine_app p f g lst = raise(Failure "Function not implemented yet.")
      
(* Problem 3 *)
let rec separate_all_from_to m n p = raise(Failure "Function not implemented yet.")
    
(* Problem 4 *)
let rec all_pred p lst = raise(Failure "Function not implemented yet.")

(* Problem 5 *)
let nearest n lst = raise(Failure "Function not implemented yet.")

(* Problem 6 *)
let rec min_max f lst = raise(Failure "Function not implemented yet.")

(* Problem 7 *)
let determine_app_base = [] (* This may need changing. *)
let determine_app_rec p f g n r = raise(Failure "Function not implemented yet.")

(* Problem 8 *)
let polar_to_cart_base = [] (* This may need changing. *)
let polar_to_cart_rec n r = raise(Failure "Function not implemented yet.") 

(* Problem 9 *)
let all_pred_base = false (* This may need changing. *)
let all_pred_rec p r n =raise(Failure "Function not implemented yet.")

(* Problem 10 *)
let nearest_base lst = raise(Failure "Function not implemented yet.")
let nearest_rec n r x = raise(Failure "Function not implemented yet.")

(* Problem 11 *)
let app_all_with fs b list  = raise(Failure "Function not implemented yet.")

(* Problem 12 *)
let subk n m k = raise(Failure "Function not implemented yet.")
let catk a b k = raise(Failure "Function not implemented yet.")
let absk x k = raise(Failure "Function not implemented yet.")
let plusk x y k = raise(Failure "Function not implemented yet.")
let multk x y k = raise(Failure "Function not implemented yet.")
let is_posk n k = raise(Failure "Function not implemented yet.")

(* Problem 13 *)
let abcdk a b c d k = raise(Failure "Function not implemented yet.")

(* Problem 14 *)
let rec polar_to_cartk lst k = raise(Failure "Function not implemented yet.")

(* Problem 15 *)
let rec all_predk pk lst k = raise(Failure "Function not implemented yet.")

(* Problem 16 *)
let nearestk n lst k = raise(Failure "Function not implemented yet.")

