/*
Author: Tengfei Mu, Rohit Soni, Eric Almeida
Note: Before compile this code, make sure you change:
1. #define N: it is the total number of machines you want to connect
2. IpTable initialization in the main function
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

#define N 5 //total number of machines
#define PORTNO 5500
#define PORTNO1 5501 //For monitoring heartbeat messages, every machine use two port (5500 and 5501) to monitor two machines seperately

int orderM;//Local Machine Number
char * IpTable[100];//This could support as many machines as the customer want, here it is 100
char buffer4server1[2];
char buffer4server2[2];//two global buffer for reading heartbeat messages from different machines

//this struct is for passing parameters to the p-thread
typedef struct my_struct {
	int monitorM;
	int serverN;
}my_struct_t;

my_struct_t st11, st22;
my_struct_t st4server1, st4server2;

//error function
void error(char *msg)
{
    perror(msg);
    exit(0);
}

//function for connecting to machine (n+1)%N and (n+2)%n and then send heartbeat message every 5 seconds
void  * threadClient(void * str) {
	int sockfd, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    char buffer[2];

	//open socket first
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");

	//while loop to try to connect to the remote monitoring machine
	while(1) {
		server = gethostbyname(IpTable[((my_struct_t*)str)->monitorM]);
    	if (server == NULL) {
        	fprintf(stderr,"ERROR, no such host\n");
        	exit(0);
    	}
    	bzero((char *) &serv_addr, sizeof(serv_addr));
    	serv_addr.sin_family = AF_INET;
    	bcopy((char *)server->h_addr, 
		  	(char *)&serv_addr.sin_addr.s_addr,
		  	server->h_length);

		//two different remote machine use different ports
		if (((my_struct_t*)str)->monitorM == ((orderM + 1) % N))
			serv_addr.sin_port = htons(PORTNO);
		else
			serv_addr.sin_port = htons(PORTNO1);
		if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) {//if not connected, then sleep 1 second and try connect again
			printf("Connection to machine %d failed and will try later\n", ((my_struct_t*)str)->monitorM);
			sleep(1);
		} else
			break;
	}
   
	//once the connection to remote machine then try to send heartbeat message every 5 seconds
	while(1) {
		buffer[0] = orderM + '0';
		buffer[1] = '\0';
		n = send(sockfd, buffer, 1, MSG_NOSIGNAL);
		if (n < 0) {
			return;
		} 
		sleep(5);
	}
    return 0;
}

//Reading on the socket and put the incoming heartbeat message in the globalbuffer for later look up
void  * readThread(void *str) {
	int n;
	int newsockfd = ((my_struct_t *)str)->monitorM;
	if (((my_struct_t *)str)->serverN == 0) {//if this is 1st monitoring thread, then put it in the first global buffer
		n = read(newsockfd, buffer4server1, 9);
	} else {
		n = read(newsockfd, buffer4server2, 9);
	}
}

//Monitoring thread function: they are used to listen on socket for incoming heartbeat messages
void  * multithreadServer(void *str) {
	struct sockaddr_in cli_addr;
	int newsockfd, clilen, n;
	int monitorM;
	int alive = 2;
	int flag = 0;
	pthread_t iThreadId1, iThreadId2;

	//monitoring thread first listen on socket and wait the incoming connections
	listen(((my_struct_t *)str)->monitorM,5);
	clilen = sizeof(cli_addr);
	newsockfd = accept(((my_struct_t *)str)->monitorM, 
					   (struct sockaddr *) &cli_addr, 
					   &clilen);
	if (newsockfd < 0) 
		error("ERROR on accept");
	
	//use while loop to check whether the remote machine is alive every 5 seconds
	while(1) {
		//The 1st monitoring thread
		if (((my_struct_t *)str)->serverN == 0) {
			//the first time it is connected. Then it will initialize some parameters and then create a thread to listen on the socket 
			if (flag == 0) {
				flag = 1;
				n = read(newsockfd, buffer4server1, 9);
				monitorM = buffer4server1[0] - '0';
				printf("Machine %d is alive!\n", buffer4server1[0] - '0');
				buffer4server1[0] = '\0';
				st4server1.monitorM = newsockfd;
				st4server1.serverN = 0;
				pthread_create(&iThreadId1, NULL, &readThread, (void *)&st4server1);
				sleep(5);
			} else {//not the first time, then check the globalbuffer to see whether it has received heartbeat message.
				if (buffer4server1[0] == '\0') {//if not receive, then tolerate once and then report failure
					if (alive == 1) {
						printf("Machine %d is dead!\n", monitorM);
						close(newsockfd);
						return;
					} else if (alive == 2) {
						printf("Live Warning: I didn't get Machine %d message!\n", monitorM);
						alive = alive - 1;
						sleep(5);
					}
				} else if ((buffer4server1[0] - '0') == monitorM) {//if received, then report machine is alive
					alive = 2;
					printf("Machine %d is alive!\n", monitorM);
					buffer4server1[0] = '\0';
					st4server1.monitorM = newsockfd;
					st4server1.serverN = 0;
					pthread_create(&iThreadId1, NULL, &readThread, (void *)&st4server1);
					sleep(5);
				} else {
					printf("Machine %d is dead!\n", monitorM);
					buffer4server1[0] = '\0';
					close(newsockfd);
					return;
				}
			}	
		} else if (((my_struct_t *)str)->serverN == 1) {//the 2nd monitoring thread
			if (flag == 0) {
				flag = 1;
				n = read(newsockfd, buffer4server2, 9);
				monitorM = buffer4server2[0] - '0';
				printf("Machine %d is alive!\n", buffer4server2[0] - '0');
				buffer4server2[0] = '\0';
				st4server2.monitorM = newsockfd;
				st4server2.serverN = 1;
				pthread_create(&iThreadId2, NULL, &readThread, (void *)&st4server2);
				sleep(5);
			} else {
				if (buffer4server2[0] == '\0') {
					if (alive == 1) {
						printf("Machine %d is dead!\n", monitorM);
						close(newsockfd);
						return;
					} else if (alive == 2) {
						printf("Live Warning: I didn't get Machine %d message!\n", monitorM);
						alive = alive - 1;
						//pthread_create(&iThreadId1, NULL, &readThread, (void *)&st4server1);
						sleep(5);
					}
				} else if ((buffer4server2[0] - '0') == monitorM) {
					alive = 2;
					printf("Machine %d is alive!\n", monitorM);
					buffer4server2[0] = '\0';
					st4server2.monitorM = newsockfd;
					st4server2.serverN = 1;
					pthread_create(&iThreadId2, NULL, &readThread, (void *)&st4server2);
					sleep(5);
				} else {
					printf("Machine %d is dead!\n", monitorM);
					buffer4server2[0] = '\0';
					close(newsockfd);
					return;
				}
			}	
		}
	}	
}

//original monitoring thread: it will create two threads to monitor two different machines
void  * threadServer(void * str) {
	int sockfd, newsockfd, clilen,sockfd1;
	struct sockaddr_in serv_addr, serv_addr1;

	//open two socket for monitoring two machines
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	sockfd1 = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0 || sockfd1 < 0) 
        error("ERROR opening socket");
	
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(PORTNO);
	
	bzero((char *) &serv_addr1, sizeof(serv_addr1));
	serv_addr1.sin_family = AF_INET;
	serv_addr1.sin_addr.s_addr = INADDR_ANY;
	serv_addr1.sin_port = htons(PORTNO1);
	if (bind(sockfd, (struct sockaddr *) &serv_addr,
			 sizeof(serv_addr)) < 0) {
		error("ERROR on binding");
	}
	if (bind(sockfd1, (struct sockaddr *) &serv_addr1,
			 sizeof(serv_addr1)) < 0) {
		error("ERROR on binding");
	}
	
	pthread_t iThreadId11, iThreadId22;
	st11.monitorM = sockfd;
	st11.serverN = 0;
	st22.monitorM = sockfd1;
	st22.serverN = 1;
	//create two thread to monitoring two machines
	pthread_create(&iThreadId11, NULL, &multithreadServer, (void *)&st11);
	pthread_create(&iThreadId22, NULL, &multithreadServer, (void *)&st22);

	return 0; 
}




int main(int argc, char *argv[]) {
	pthread_t iThreadId1, iThreadId2, iThreadId3;
	my_struct_t st1, st2, st3;
	//initialize the fixed IPtable accroding to the machines that will be connected together
	IpTable[0] = "192.17.11.77";
	IpTable[1] = "192.17.11.78";
	IpTable[2] = "192.17.11.76";
	IpTable[3] = "192.17.11.75";//change the ip address every time
	IpTable[4] = "192.17.11.69";

	if(argc <= 1) {
		printf("The command format should be: ./fd n\n");
		return 0;
	}
	orderM = atoi(argv[1]);//orderM is the order of this machine and it should between 0 and N-1
	if (orderM < 0 || orderM >= N) {
		printf("n should be between 0 and N\n");
		return 0;
	}
	
	//new thread to creat connection to machine (n+1) mod N for sending heartbeat messages
	st1.monitorM = (orderM + 1) % N;
	pthread_create(&iThreadId1, NULL, &threadClient, (void *)&st1);
	//new thread to creat connection to machine (n+1) mod N for sending heartbeat messages
	st2.monitorM = (orderM + 2) % N;
	pthread_create(&iThreadId2, NULL, &threadClient, (void *)&st2);

	//new thread to monitor incoming heartbeat messages
	pthread_create(&iThreadId3, NULL, &threadServer, (void *)&st3);
	
	//while 1 loop to make the process run forever
	while(1) {
	}
	return 1;
}
