Author: Tengfei Mu, Rohit Soni, Eric Almeida Note: This file is used to
describe how to compile our fd.c code and what functions in the code

Part 1. Before and How compile:

1. #define N: it is the total number of machines you want to connect 2.
IpTable initialization in the main function

Before compile: You need to make sure the IpTable is initialized with the
actuall IP address of your machines. This should be done in the beginning of
the main function. Also, change the total number of machines that you want to
connect. That is #define N * (at top of the source code) As for compile: you
can type command: "gcc -o fd fd.c -lpthread" Usage: For run, you need to type
the command: "./fd computerIDNumber".  ComputerID number is the index in the
IpTable array where the IP address of the computer you are running on is set.

Part 2. Understanding the code: main(): Initialize the IpTable[] and create 3
threads. Two client threads (threadClient) to send heartbeat messages to two
monitoring machine. And one server thread (threadServer) to receive the
incoming heartbeat messages.

threadClient(): try to connect to the remote monitoring machine. Then send the
heartbeat messages every 5 seconds

threadServer(): This thread will create two threads (multithreadServer) to
receive incoming heartbeat messages from two different machines seperately

multithreadServer(): This thread will accept the incoming connection request,
and then create another thread (readThread) to read the incoming heartbeat
messages and it checks the global buffer every 5 seconds.

