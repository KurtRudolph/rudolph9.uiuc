/*
 * Generator.cpp
 *
 *  Created on: Oct 27, 2010
 *      Author: anupam
 */

#include <string>
#include <iostream>
#include "Load_balance.h"

using namespace std;

const string defaultConfigFile = "/home/anupam/workspace/Load balanced tree/value.conf";


int main(int argc,  char *argv[])
{
    string configFile = defaultConfigFile;
    //  Parse  the command line to get the configuration file
    //  and other options
    if(argc > 1) {
    	configFile = argv[1];
    }

    Load_balance  findvalue(configFile);

    cout << "started computing"<< endl;

    findvalue.Calculate_Load_balance();

    cout << "exiting..."<<endl;
    return 0;
}
