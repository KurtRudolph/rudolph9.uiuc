#ifndef MYFD_HPP__
#define MYFD_HPP__

#include "Node.hpp"
#include "BSTNode.hpp"

// Arguments for the listener thread
struct IOArgs
{
    Node self;
};

// Arguments for the listener thread
struct ListenerArgs
{
    Node self;
};

// Arguments for the receiver pthread
struct ReceiverArgs
{
    Node self;
};

// Arguments for the sender pthread
struct SenderArgs
{
    Node self;
    Node peer;
};


// print the usage information to stdout
static void usage(void);

// parse the configuration file in order to extract node information
static std::vector<Node> parse_config(const char *filename);

// get list of hostnames for host
static std::vector<std::string> gethostnames(void);

// return the local node
static Node locate_local_node(std::vector<std::string>& hostnames, std::vector<Node>& nodes);

static void dispatch_threads(const Node& self);
static void* io_start(void* arg);
static void* listener_start(void* arg);

static int submit_instruction(int type,Node& self, Node& root, int key, int value);

#endif
