#include "BSTNode.hpp"

// Empty class definition since gcc does note work nicely with templated classes
