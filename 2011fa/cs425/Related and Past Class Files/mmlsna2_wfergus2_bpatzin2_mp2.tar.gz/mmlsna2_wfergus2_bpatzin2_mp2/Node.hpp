#ifndef NODE_HPP_
#define NODE_HPP_
#include <string>
#include <netdb.h>

// A node in the sytem
class Node
{
    public:
        int id;                 // Unique ID of the node
        std::string hostname;   // Node hostname
        std::string port;       // Node port
        std::string io_port;    // Node port

        struct addrinfo addrinfo;
        struct addrinfo io_addrinfo;


        Node(void);
        Node(int id, std::string hostname, std::string port, std::string io_port);

        bool operator==(const Node& other) const;

        friend std::ostream& operator<<(std::ostream& stream, Node node);
};

#endif
