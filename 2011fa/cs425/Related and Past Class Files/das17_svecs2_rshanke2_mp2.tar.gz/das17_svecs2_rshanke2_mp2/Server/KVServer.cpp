#include "KVServer.h"

// Utility function used to tokenize strings
void Tokenize(const string& str, vector<string>& tokens, const string& delimiters) 
{
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}

// Populates the list of machines
void KVServer::AddNeighborEntry(int machineNum,string &hostName, int port)
{
 
    MachineAddr *machine = new MachineAddr();
    machine->hostName = hostName;
    machine->port = port;
    machineAddrMap[machineNum]=machine;
}
// Parses the config file and populates the server parameters based on those entries

void KVServer::ParseConfigFile(const string &configFile)
{
	ifstream file;

	file.open(configFile.c_str());
	if(!file) {
		FAIL("Could not open configuration file: " + configFile);
	}
    mNumServerThreads = DEFAULT_NUM_SERVER_THREADS;
    mTotalMachines  = DEFAULT_NUM_MACHINES;
	mLeafLevel      = DEFAULT_LEAF_LEVEL;

	string line;
	while(getline(file, line)) {
		if(line.empty()) continue;
		vector<string> tokens;
		Tokenize(line, tokens);
		if(tokens.size() < 2 || (tokens.size() > 0 && tokens[0][0] == '#')) {
			continue; // skip comments and invalid lines
		}
		string& keyword = tokens[0];
		string& value = tokens[1];
		if(keyword == "numThreads") {
			mNumServerThreads = atoi(value.c_str());
		}
        if(keyword == "numMachines") {
            mTotalMachines = atoi( value.c_str());
    		machineAddrMap = new MachineAddr*[mTotalMachines+1]; // we count from 1
        }
		else
		if(keyword == "leafLevel") {
			mLeafLevel = atoi( value.c_str());
		}
        else
        if(keyword == "port") {
            mPort = atoi(value.c_str());
        }
        else
        if(keyword == "machine") {
            mId     = atoi(value.c_str());
        }
        else
        if(keyword == "neighbor") {
            if( tokens.size() < 4 ) {
                FAIL("error parsing neighbor in configuration file");
            }
            AddNeighborEntry(atoi(tokens[1].c_str()),tokens[2],atoi(tokens[3].c_str()));
        }
        else
        if(keyword == "node")  {
            if(tokens.size() < 5 ) {
                FAIL("error parsing node entry in configuration file");
            }
            m_id_t machineId = (m_id_t) atoi(tokens[1].c_str());
            // We assume machine is given initially
            // We will skip all other entries that do not correspond to ourself
            if( machineId != mId )
                continue;

            //#keyword    Machine Level   Index   Key-Range   LEFT    (Machine,Level,Index,Key-Range) RIGHT (Machine,Level,Index,Key-Range)
            // node        1       1       1       500000              2        2      1     250000            3       2       2   750000

            int level = atoi(tokens[2].c_str());
            int index = atoi(tokens[3].c_str());
            keytype_t  comparisonKey   = (keytype_t) atoi(tokens[4].c_str());
            if( level == (mLeafLevel) )
            {
                struct LeafNode *pLeaf = new LeafNode(); 
                pLeaf->key = comparisonKey;
                pthread_mutex_init(&pLeaf->leftLock,NULL);
                pthread_mutex_init(&pLeaf->rightLock,NULL);
                pair<int,int> lookup(level,index);
                mLeafNodes[lookup]=pLeaf;
            }
            else
            {

            	if(tokens.size() < 13 ) {
                	FAIL("error parsing node entry in configuration file");
            	}
                struct InternalNode *pInternal = new InternalNode();  

                pInternal->key = comparisonKey;

                pInternal->left.machineNum =    atoi(tokens[5].c_str());
                pInternal->left.level =         atoi(tokens[6].c_str());
                pInternal->left.index =         atoi(tokens[7].c_str());

                pInternal->right.machineNum =   atoi(tokens[9].c_str());
                pInternal->right.level      =   atoi(tokens[10].c_str());
                pInternal->right.index      =   atoi(tokens[11].c_str());

                pair<int,int>  lookup(level,index);
                mInternalNodes[lookup] = pInternal;
            }

        }
    }

    mPeerSocks     = new int[mTotalMachines+1]; 
	file.close();
}

KVServer::KVServer(const string& configFile)
{
    ParseConfigFile(configFile);
	LOG_MSG("Finished parsing configuration file ");
    CreateServerSocket();
	LOG_MSG("Server: " << mId << " listening on " << mPort );
}

// Re-entrant version of gethostbyname, available online
struct hostent *
gethostname (const char *host)
{
  struct hostent hostbuf, *hp;
  size_t hstbuflen;
  char *tmphstbuf;
  int res;
  int herr;

  hstbuflen = 1024;
  /* Allocate buffer, remember to free it to avoid memory leakage.  */
  tmphstbuf = (char*)malloc (hstbuflen);

  while ((res = gethostbyname_r (host, &hostbuf, tmphstbuf, hstbuflen,
                                 &hp, &herr)) == ERANGE)
    {
      /* Enlarge the buffer.  */
      hstbuflen *= 2;
      tmphstbuf = (char*) realloc (tmphstbuf, hstbuflen);
    }
  /*  Check for errors.  */
  if (res || hp == NULL)
    return NULL;
  return hp;
}


// This creates sockets on which we send to other machines (including ourselves)
void KVServer::CreatePeerSockets()
{
	DEBUG_MSG("Creating PeerSockets");

	for(int id = 1; id <= mTotalMachines ; id++)
	{
		string serverName = machineAddrMap[id]->hostName;
		int port = machineAddrMap[id]->port;
		DEBUG_MSG("Trying to connect to "<< serverName << " at port " << port );
		struct sockaddr_in servAddr;
		struct hostent *servEnt;


		int sockfd = socket(AF_INET,SOCK_STREAM,0);
		if( sockfd < 0)
			FAIL("Error opening socket");
		servEnt = gethostbyname(serverName.c_str());
		if (servEnt == NULL) {
			FAIL("Cannot find server");
		}
		bzero((char *) &servAddr, sizeof(servAddr));
		servAddr.sin_family = AF_INET;
		bcopy((char *)servEnt->h_addr, (char *)&servAddr.sin_addr.s_addr,servEnt->h_length);
		servAddr.sin_port = htons(port);
		int numTries = 0;
		while( 1)
		{
			int rc = connect(sockfd,(struct sockaddr *)&servAddr,sizeof(servAddr));
			if( rc == 0 )
				break;
			numTries++;
			if( numTries > MAX_NUM_RETRIES_TO_CONNECT )
				FAIL("Cannot connect to server");
			sleep(CONNECTION_RETRY_INTERVAL);
			LOG_MSG("Trying to connect to "<< serverName << " at port " << port << " try number " << numTries);
		}
		mPeerSocks[id]=sockfd;

        struct sockaddr_in localAddr;
        socklen_t addrLen;
        int retVal = getsockname(sockfd, (struct sockaddr *) &localAddr, &addrLen);
        if(retVal == 0)
        {
            char buf[INET_ADDRSTRLEN];
            inet_ntop(AF_INET,&(localAddr.sin_addr),buf,INET_ADDRSTRLEN);
            LOG_MSG(" Peer socket established to " << id << " listening on " << buf << " Port " << localAddr.sin_port );
        }
	}
	DEBUG_MSG("Finished creating PeerSockets");
	LOG_MSG("Finished connecting to peer-machines ");
}

// This creates a socket on which we listen for incoming requests
void KVServer::CreateServerSocket()
{
	DEBUG_MSG("About to create socket for listening on ");
	if((mSrvSock= socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		FAIL("could not create server socket()");
	}
	memset(&mSrvSockAddr, 0, sizeof(mSrvSockAddr));
	mSrvSockAddr.sin_family = AF_INET;
	mSrvSockAddr.sin_port = htons(static_cast<uint16_t>(mPort));
	mSrvSockAddr.sin_addr.s_addr = INADDR_ANY;
	if(bind(mSrvSock, (struct sockaddr *)&mSrvSockAddr, sizeof(mSrvSockAddr)) < 0) {
		FAIL("could not bind()");
	}
    //  Have to verify that (mNumServerThreads * 2) is a good backlog limit or not
	if(listen(mSrvSock, 1000) < 0) {
		FAIL("could not listen()");
	}
	// WARNING -- may not be portable
	int on = 1;
	setsockopt(mSrvSock, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	DEBUG_MSG("Finished creating server socket on port " << mPort);
}

// Forward the request to the given machine
void KVServer::RedirectPackage(m_id_t machineId,RequestPacket reqPacket)
{
    LOG_MSG("SRV-SRV: Redirecting client package to " << (int) machineId );
    int n = send(mPeerSocks[machineId],(char*)&reqPacket,sizeof(reqPacket),MSG_NOSIGNAL);
    if(n < (int)sizeof(reqPacket) )
        FAIL("Error forwarding request");
}

int GetClientSocket(RequestPacket reqPacket)
{

    struct sockaddr_in clientAddr;
    struct hostent *clientEnt;

    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    if( sockfd < 0)
        FAIL("Error opening socket");

    char clientName[INET_ADDRSTRLEN+1];
    in_addr_t cAddrType;
    struct in_addr cAddr;
    cAddrType = (in_addr_t)reqPacket.clientAddr;
    cAddr.s_addr = cAddrType;
    // TODO:  check if this is required
    inet_ntop(AF_INET, &(cAddr), clientName, INET_ADDRSTRLEN);
    clientEnt = gethostbyname(clientName);
    if (clientEnt == NULL) {
        FAIL("Cannot find server");
    }
    bzero((char *) &clientAddr, sizeof(clientAddr));
    clientAddr.sin_family = AF_INET;
    bcopy((char *)clientEnt->h_addr, (char *)&clientAddr.sin_addr.s_addr,clientEnt->h_length);
    clientAddr.sin_port = htons(reqPacket.clientPort);

    if (connect(sockfd,(struct sockaddr *)&clientAddr,sizeof(clientAddr)) < 0) 
        FAIL("Cannot connect to client");
    DEBUG_MSG("Connected to client to send the response ");
    return sockfd;
}

// Handle Get Request
void KVServer::HandleGetRequest(RequestPacket reqPacket)
{
    // This means that we are at the leaf level
    pair<int,int>  p(reqPacket.level,reqPacket.index);
    LeafNode *pLeaf = mLeafNodes[p];
    struct ResponsePacket resp;
    resp.transId = reqPacket.transId;

    DEBUG_MSG("Handling GET request key " << reqPacket.key << " transaction " << reqPacket.transId );
    if( pLeaf == NULL )
    {
        DEBUG_MSG("Error KV store is NULL ");
    }
    else
        DEBUG_MSG("Debug Store is not NULL: Store Key " << pLeaf->key << " Request Key  " << reqPacket.key);

    int sockfd = GetClientSocket(reqPacket);


    if( pLeaf->key <= reqPacket.key )
    {
        pthread_mutex_lock(&pLeaf->leftLock);
        uint32_t key = reqPacket.key;
        map<int,char*>::iterator it;
        it = pLeaf->leftBin.find(key);
        if(it == pLeaf->leftBin.end())
        {
            // not found
            DEBUG_MSG("Debug Store iterator not found sending response" );
            resp.length=0;
			LOG_MSG("SRV-CLI:  Server Response for transaction "<< resp.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int)sizeof(ResponsePacket) ) 
                FAIL("Error sending response");

        }
        else
        {
            resp.length = strlen( (*it).second );
			LOG_MSG("SRV-CLI:  Server Response for transaction "<< resp.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int)sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
            n = send(sockfd,(*it).second,resp.length,MSG_NOSIGNAL );
            if ( n < resp.length)
                FAIL("Error sending response");
        }
        pthread_mutex_unlock(&pLeaf->leftLock);
    }
    else
    {
        pthread_mutex_lock(&pLeaf->rightLock);
        uint32_t key = reqPacket.key;
        map<int,char*>::iterator it;
        it = pLeaf->rightBin.find(key);
        if(it == pLeaf->rightBin.end())
        {
            // not found
            resp.length=0;
			LOG_MSG("SRV-CLI:  Server Response for transaction "<< resp.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int) sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
        }
        else
        {
            resp.length = strlen( (*it).second );
			LOG_MSG("SRV-CLI:  Server Response for transaction "<< resp.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int) sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
            n = send(sockfd,(*it).second,resp.length,MSG_NOSIGNAL );
            if ( n < resp.length)
                FAIL("Error sending response");
        }
        pthread_mutex_unlock(&pLeaf->rightLock);
    }
    DEBUG_MSG("Exiting from HandleGetRequest");
    close(sockfd);
}

// Handle Put Request
void KVServer::HandlePutRequest(RequestPacket reqPacket)
{
    // This means that we are at the leaf level
    pair<int,int>  p(reqPacket.level,reqPacket.index);
    LeafNode *pLeaf = mLeafNodes[p];
    struct ResponsePacket resp;
    resp.transId = reqPacket.transId;

    int sockfd = GetClientSocket(reqPacket);
    // Now ask the client for the put data
    //XXX:  This is optional
	LOG_MSG("SRV-CLI: Server requesting PUT data for transaction " << reqPacket.transId);
    char tokenSend=1;
    int nr = send(sockfd,&tokenSend,1,MSG_NOSIGNAL);
    uint32_t putLength;
    nr = recv(sockfd,(char*)&putLength,sizeof(putLength),0);
    if( nr < (int)sizeof(putLength) )
        FAIL_THREAD("Error getting put length");
	char *buf = new char[putLength+1];
	LOG_MSG("SRV-IN: Server got PUT data for transaction " << reqPacket.transId);
    nr = recv(sockfd,buf,putLength,0);
    if( nr < (int) putLength )
        FAIL_THREAD("Error getting put data");
	buf[putLength]='\0';

    if( pLeaf->key <= reqPacket.key )
    {
        pthread_mutex_lock(&pLeaf->leftLock);
        uint32_t key = reqPacket.key;
        map<int,char*>::iterator it;
        it = pLeaf->leftBin.find(key);
        if(it == pLeaf->leftBin.end())
        {
            // not found
            resp.length=0;
			LOG_MSG("SRV-CLI: Server sending (no earlier) PUT data for transaction " << reqPacket.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int)sizeof(ResponsePacket) ) 
            	FAIL("Error sending response");
        }
        else
        {
            resp.length = strlen( (*it).second );
			LOG_MSG("SRV-CLI: Server sending old PUT data for transaction " << reqPacket.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int)sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
            n = send(sockfd,(*it).second,resp.length ,0);
            if ( n < resp.length)
                FAIL("Error sending response");
        }
		pLeaf->leftBin[key]=buf;
        pthread_mutex_unlock(&pLeaf->leftLock);
    }
    else
    {
        pthread_mutex_lock(&pLeaf->rightLock);
        uint32_t key = reqPacket.key;
        map<int,char*>::iterator it;
        it = pLeaf->rightBin.find(key);
        if(it == pLeaf->rightBin.end())
        {
            // not found
            resp.length=0;
			LOG_MSG("SRV-CLI: Server sending (no earlier) PUT data for transaction " << reqPacket.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int) sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
        }
        else
        {
            resp.length = strlen( (*it).second );
			LOG_MSG("SRV-CLI: Server sending old PUT data for transaction " << reqPacket.transId);
            int n = send(sockfd,(char *)&resp,sizeof(ResponsePacket),MSG_NOSIGNAL);
            if( n < (int) sizeof(ResponsePacket) ) 
                FAIL("Error sending response");
            n = send(sockfd,(*it).second,resp.length,MSG_NOSIGNAL );
            if ( n < resp.length)
                FAIL("Error sending response");
        }
		pLeaf->rightBin[key]=buf;
        pthread_mutex_unlock(&pLeaf->rightLock);
    }
    close(sockfd);


}

// Handle Delete Request
void KVServer::HandleDeleteRequest(RequestPacket reqPacket)
{
    // This means that we are at the leaf level
    pair<int,int>  p(reqPacket.level,reqPacket.index);
    LeafNode *pLeaf = mLeafNodes[p];
    struct ResponsePacket resp;
    resp.transId = reqPacket.transId;
    resp.length = 0;

    int sockfd = GetClientSocket(reqPacket);

    if( pLeaf->key <= reqPacket.key )
    {
        pthread_mutex_lock(&pLeaf->leftLock);
        uint32_t key = reqPacket.key;
        pLeaf->leftBin.erase(key);
		// TODO:  Handle de-allocation of buffer
       pthread_mutex_unlock(&pLeaf->leftLock);
    }
    else
    {
        pthread_mutex_lock(&pLeaf->rightLock);
        uint32_t key = reqPacket.key;
        pLeaf->rightBin.erase(key);
		// TODO:  Handle de-allocation of buffer
       pthread_mutex_unlock(&pLeaf->rightLock);
    }
	LOG_MSG("SRV-CLI: Server sending old stored data before delete for transaction " << reqPacket.transId);
    int n = send(sockfd,(char *)&resp, sizeof(ResponsePacket),MSG_NOSIGNAL);
    if( n < (int) sizeof(ResponsePacket))
        FAIL("Error sending response");

    close(sockfd);
}


int GetClientRequest(RequestPacket &reqPacket,int fd)
{
    int nr = recv(fd,&reqPacket,sizeof(reqPacket),0);
    if( nr < (int) sizeof(reqPacket))
    {
        DEBUG_MSG("Error cannot receive client request: Got " << nr << " from recv, and socket is " << fd);
        return -1;
    }
    return 0;
}



//  Handles incoming requests
void * KVServer::HandleRequest(void *arg)
{
    // Keep accepting clients and handling requests
    ThreadEntry *pEntry=static_cast<ThreadEntry*>(arg);
    KVServer *pKVServ= pEntry->pServer;
    int threadId = pEntry->id;
    struct sockaddr_in callerId;
    socklen_t sockLength;
    sockLength = sizeof(sockaddr);

    RequestPacket clientReq;
    
    int fd;

    DEBUG_MSG("Thread " << threadId << "Waiting for connections: Handle-Request " );
    if((fd=accept(pKVServ->mSrvSock,(struct sockaddr*)&callerId,&sockLength)) == -1) {
        FAIL_THREAD("Could not accept connections from clients");
    }

    
    while(1)
    {
        char buf[INET_ADDRSTRLEN];
        inet_ntop(AF_INET,&(callerId.sin_addr),buf,INET_ADDRSTRLEN);
        DEBUG_MSG("Thread " << threadId << " Found a connection From " << buf << " Port " << callerId.sin_port);

        int nRead=GetClientRequest(clientReq,fd);
        if( nRead != 0 )
        {
            DEBUG_MSG("Problems receiving client request, closing connection");
            close(fd);
            LOG_MSG("Thread " << threadId << " Closed socket: " );
            DEBUG_MSG("Thread " << threadId << " Restarting: Waiting for connections: Handle-Request " );
            if((fd=accept(pKVServ->mSrvSock,(struct sockaddr*)&callerId,&sockLength)) == -1) {
                FAIL_THREAD("Could not accept connections from clients");
            }
            continue;
        }
		LOG_MSG("SRV-IN: Thread " << threadId << " Has Request at level " << (int) clientReq.level << " index " << (int) clientReq.index );
		LOG_MSG("Thread " << threadId << " Has Request with Key " << clientReq.key << " of Type " <<  ((clientReq.reqType == CLIENT_GET_REQUEST) ? " GET ": " PUT or DEL " ));

        if(clientReq.level < (pKVServ->mLeafLevel)) // This means we have to forward the request to another node
        {
            if( clientReq.level == 1 )
            {
                // Very first request, make sure that we set the incoming address properly
                clientReq.clientAddr = (uint32_t) callerId.sin_addr.s_addr;
            }

            // First look up the InternalNode corresponding to this <level,index>
            pair<int,int>  node(clientReq.level,clientReq.index);

            InternalNode *pInternal = pKVServ->mInternalNodes[node];
            int targetMachine ;
            if( clientReq.key <= pInternal->key) {
                // Choose the left one
                clientReq.level = pInternal->left.level;
                clientReq.index = pInternal->left.index;
                targetMachine = pInternal->left.machineNum;

            }else {
                // Choose the right one
                clientReq.level = pInternal->right.level;
                clientReq.index = pInternal->right.index;
                targetMachine = pInternal->right.machineNum;
            }
            pKVServ->RedirectPackage(targetMachine,clientReq);
        }
        else
        {
			LOG_MSG("SRV-HIT: Request hit the leaf level ");
            if( clientReq.reqType  == CLIENT_GET_REQUEST)
            {
                // Handle GET Request
                pKVServ->HandleGetRequest(clientReq);
                DEBUG_MSG("Finished Handle GetRequest (outerloop)");
            } else 
            if (clientReq.reqType == CLIENT_PUT_REQUEST)
            {
                    //uint16_t putLength;
                    //if( recv(fd,&putLength,sizeof(putLength),0) < (int)sizeof(putLength))
                    //    FAIL_THREAD("Error could not find enough data from PUT");
                    //char buf[putLength];
                    //if( recv(fd,buf,putLength,0) < (int)putLength )
                    //    FAIL_THREAD("Error could not find enough data from PUT");
                    pKVServ->HandlePutRequest(clientReq);
            } else
            if( clientReq.reqType ==  CLIENT_DELETE_REQUEST )
            {
                pKVServ->HandleDeleteRequest(clientReq);
            }
            else
            {
                DEBUG_MSG("Invalid request type");
            }
			LOG_MSG("SRV-CLI: Response packet sent to client");
        }
        if( ( clientReq.level == 1 ) && ( pKVServ->mId == 1 ) )
        {
            // These are not peer threads (this is connected to one client)
            LOG_MSG("Thread " << threadId << "Finished client response: ") ;
            close(fd);
            LOG_MSG("Thread " << threadId << "Closed socket: " );
            DEBUG_MSG("Thread " << threadId << "Restarting: Waiting for connections: Handle-Request " );
            if((fd=accept(pKVServ->mSrvSock,(struct sockaddr*)&callerId,&sockLength)) == -1) {
                FAIL_THREAD("Could not accept connections from clients");
            }
        }
    }
}

//  Create server threads to handle requests from clients
//  The number if threads can be specified in the configuration file (numThreads)

void KVServer::Run(void )
{
    CreatePeerSockets();
    pthread_t serviceThreads[mNumServerThreads];  // This local buffering may not be required (unless we need to handle shutdown gracefully)
	DEBUG_MSG("About to start service threads " << mNumServerThreads );

    for(int id = 0; id < mNumServerThreads  ; id++)
    {
        struct ThreadEntry *pEnt = new struct ThreadEntry();
        pEnt->id=id;
        pEnt->pServer = this;
        DEBUG_MSG("Creating thread "<<id);
		if(pthread_create(&serviceThreads[id], NULL, &KVServer::HandleRequest, pEnt) != 0) {
			FAIL("could not create accept/read thread");
		}
    }
	DEBUG_MSG("Finished creating service threads ");
	LOG_MSG("Finished creating "<< mNumServerThreads << " service threads ");

    //KVServer::HandleRequest((void*)this);   // using a single thread for testing
    while(1){
        sched_yield();
        sleep(10000);
        //KVServer::HandleRequest((void*)this);
    }
}
