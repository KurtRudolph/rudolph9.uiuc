open Mp4common

(* Problem 1 *)
let rec dept_payroll dept_list = raise(Failure "Function not implemented yet.")  

(* Problem 2 *)
let rec sum_smallest ls = raise(Failure "Function not implemented yet.")

(* Problem 3 *)
let rec gencompare a b = raise(Failure "Function not implemented yet.")

(* Problem 4 *)
let rec insert cmp e l = raise(Failure "Function not implemented yet.")

(* Problem 5 *)
let rec compare a1 a2 = raise(Failure "Function not implemented yet.")

(* Problem 6 *)
let rec eliminateImplies p = raise(Failure "Function not implemented yet.")

(* Problem 7 *)
let rec eliminateNot p = raise(Failure "Function not implemented yet.")

(* Problem 8 *)
let rec dnf p = raise(Failure "Function not implemented yet.")

(* Problem 9 *)
let rec dnf_compact p = raise(Failure "Function not implemented yet.")

(* Problem 10 *)
let rec solve d = raise(Failure "Function not implemented yet.")

(* Problem 11 *)
let rec satisfies m p = raise(Failure "Function not implemented yet.")
