/*
   This is the entry point to the KeyValue server
   It accepts incoming requests and updates the internal tree as needed
*/

#include "KVServer.h"

const string defaultConfigFile = "kvserver.conf";                                                                                                                                                                                
const string defaultLogFile=    "kvserver.log";   

// Handle Interrupt.
void terminateProgram(int sig)                                                                                                                                                                                                   
{                                                                                                                                                                                                                                
	// TODO: Log the fact that we shutdown at this time
	exit(EXIT_FAILURE);                                                                                                                                                                                                          
}  


int main(int argc, char *argv[])
{
	string configFile 	= defaultConfigFile;
	string logFile 		= defaultLogFile;
	//  Parse  the command line to get the configuration file 
    //  and other options 
    if(argc > 1) {  
		configFile = argv[1];
		if( argc > 2 )
			logFile = argv[2];
	}

	(void) signal(SIGINT,terminateProgram);
	DEBUG_MSG(" Reading configuration file ");
    KVServer  kvServer(configFile);
	DEBUG_MSG(" About to start server ");
    kvServer.Run();
	exit(EXIT_SUCCESS);    
}
