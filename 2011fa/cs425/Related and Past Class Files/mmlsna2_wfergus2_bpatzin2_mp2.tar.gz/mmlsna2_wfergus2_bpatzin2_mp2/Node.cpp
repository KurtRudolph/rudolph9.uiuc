#include "Node.hpp"

#include <iostream>


// Constructor
Node::Node(void) : id(-1), hostname(""), port("") {}

// Constructor
Node::Node(int id, std::string hostname, std::string port, std::string io_port)
    : id(id), hostname(hostname), port(port), io_port(io_port) {}

// Need operator== in order to use the std::find() algorithm
bool Node::operator==(const Node& other) const
{
    return id == other.id &&
           hostname == other.hostname &&
           port == other.port &&
           io_port == other.io_port;
}

// For easy printing
std::ostream& operator<<(std::ostream& stream, Node node)
{
    stream << "Node[id = " << node.id << ", address = " <<
        node.hostname << ":" << node.port <<  node.io_port << "]";
    return stream;
}
