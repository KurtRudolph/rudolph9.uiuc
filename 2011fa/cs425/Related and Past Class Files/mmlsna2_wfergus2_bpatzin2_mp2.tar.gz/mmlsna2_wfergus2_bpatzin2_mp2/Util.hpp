#ifndef UTIL_HPP_
#define UTIL_HPP_

// get IP address
void *get_in_addr(struct sockaddr *sa);

void ERROR_EXIT(const std::string& message);

#endif
