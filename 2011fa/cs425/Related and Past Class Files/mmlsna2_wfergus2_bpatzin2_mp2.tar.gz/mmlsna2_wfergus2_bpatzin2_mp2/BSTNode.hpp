#ifndef BSTNODE_H_
#define BSTNODE_H_

#include <cstddef>

template <class T>

struct BSTNode
{
    BSTNode(void);
    BSTNode(int id);
    int id;
    int left_id;
    int right_id;
    int parent_id;
    T data[31250];
};

// Include class definition inside of the header file since
// gcc does not work nicely with separate declaration and
// definition of class templates

template <class T>
BSTNode<T>::BSTNode(void)
{
    this->id = 0;
    this->left_id = 0;
    this->right_id = 0;
    this->parent_id = 0;
}

template <class T>
BSTNode<T>::BSTNode(int id)
{
    this->id = id;
    this->left_id = id * 2 + 1;
    this->right_id = id * 2 + 2;
    this->parent_id = (id - 1) / 2;
}

#endif
